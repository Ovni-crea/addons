# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Plugin de Lectura de Comics
# Version 0.0.1 (30.04.2018)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)
# Gracias a la Idea General de PalcoTV

import os
import sys
import urllib
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import time
import shutil

import plugintools, requests
import resolvers
from __main__ import *

from comics import *


from __main__ import *

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

version = "(v0.0.3)"

addonPath           = xbmcaddon.Addon().getAddonInfo("path")
mi_data = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.comics/'))
mi_addon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.comics'))
jpg = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.comics/jpg/'))
listaprin = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.comics/lista.txt'))
almacen = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.comics/almacen.txt'))
listacopia = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.comics/copia_lista.txt'))
master = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.comics/master.txt'))
almacen_master = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.comics/almacen_master.txt'))
temp = xbmc.translatePath(os.path.join('special://home/userdata/playlists/tmp', ''))
playlists = xbmc.translatePath(os.path.join('special://home/userdata/playlists', ''))
fich_lista = xbmc.translatePath(os.path.join(mi_addon ,"lista_comics.txt"))


if not os.path.exists(mi_data):
	os.makedirs(mi_data)  # Si no existe el directorio, lo creo
	
if not os.path.exists(listaprin):
	shutil.copyfile(master , listaprin)

if not os.path.exists(almacen):
	shutil.copyfile(almacen_master , almacen)

if not os.path.exists(playlists):
	os.makedirs(playlists)  # Si no existe el directorio, lo creo

if not os.path.exists(temp):
	os.makedirs(temp)  # Si no existe el directorio, lo creo

cabecera = "[COLOR blue][B]     Visor De Comics  "+version+" [COLOR red]····[COLOR yellow]by Bad-Max[COLOR red]····[/B][/COLOR]"
logoprin= "https://i.imgur.com/lhaGon8.png"
fondoprin = "https://i.imgur.com/PROZoe3.png"

params2 = plugintools.get_params()

# Entry point

def run():
	plugintools.log('[%s %s] Running %s... ' % (addonName, addonVersion, addonName))

	# Obteniendo parámetros...
	params = plugintools.get_params()
   
	if params.get("action") is None:
		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"
	

	#main_list(params)

	plugintools.close_item_list()            



# Main menu
def main_list(params):

	plugintools.add_item(action="",url="",title=cabecera,thumbnail=logoprin, fanart=fondoprin,folder=False,isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logoprin, fanart=fondoprin, folder=False, isPlayable=False)

	plugintools.add_item(action="lista0",url="",title="[COLOR white]-Mis Comics[/COLOR]", extra="", thumbnail=logoprin, fanart=fondoprin, folder=True, isPlayable=False)
	plugintools.add_item(action="busca_comic",url="",title="[COLOR lime][B]-Búsqueda Por Título[/B][/COLOR]",thumbnail="https://i.imgur.com/7wX6FXB.png", fanart=fondoprin, folder=True, isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logoprin, fanart=fondoprin, folder=False, isPlayable=False)

	plugintools.add_item(action="gestion_lista",url="",title="[COLOR white]-Gestión de Lista de Comics[/COLOR]", extra="", thumbnail="https://i.imgur.com/WrQO5K5.png", fanart=fondoprin, folder=True, isPlayable=False)
	plugintools.add_item(action="borratmp",url="",title="[COLOR red]-Eliminar Ficheros y Carpetas Temporales[/COLOR]", extra="", thumbnail="https://i.imgur.com/x2dl1T8.png", fanart=fondoprin, folder=False, isPlayable=False)
	plugintools.add_item(action="slide_cbx", title="[B][COLOR blue]-Instrucciones Básicas[/B][/COLOR]", url=jpg, page="1", extra=jpg  , thumbnail = "https://i.imgur.com/m3Jy9m6.png", fanart=fondoprin, folder=False, isPlayable=False)    

	
	plugintools.add_item(action="salida",url="",title="[COLOR green][B]- Salir[/B][/COLOR]",thumbnail="https://i.imgur.com/mYwFgRr.png",extra="", fanart="https://i.imgur.com/Cp1t1lb.png", folder=False, isPlayable=False)

	
	
	
def lista0(params):
	plugintools.add_item(action="",url="",title=cabecera,thumbnail=logoprin,fanart=fondoprin,folder=False,isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logoprin, fanart=fondoprin, folder=False, isPlayable=False)

	plugintools.set_view(plugintools.TV_SHOWS)
		
	fh = open(listaprin, "r")
	data = fh.read()
	fh.close()

	comics = plugintools.find_multiple_matches(data,'<Line>(.*?)</Line>')
	
	#Los ordeno y pongo identificativo de cambio de letra
	#para que no exista desorden entre mayusculas y minusculas... pongo titulo en formato Title()
	listas_orden=[]
	for item in comics:
		titu = plugintools.find_single_match(item,'titu=(.*?)url=').strip()
		if len(titu) <> 0:
			listas_orden.append(item.replace(titu, titu.title()))
		
	listas_orden.sort()

	popdata=open(fich_lista, "w+")

	for item2 in listas_orden:
		popdata.write(item2+"\n")

	popdata.close()

	
	puntero1 = 0
	paginacion(puntero1,"",params)


def gestion_lista(params):
	logo = params.get("thumbnail")

	plugintools.add_item(action="",url="",title="[COLOR lime][B]      ···Gestión de Lista de Comics···[/B][/COLOR]",thumbnail=logo, fanart=fondoprin,folder=False,isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logo, fanart=fondoprin, folder=False, isPlayable=False)

	plugintools.add_item(action="agrega_comic",url="",title="[COLOR white]-Añadir Un Comic Manualmente[/COLOR]", extra="", thumbnail="https://i.imgur.com/egHIgCu.png", fanart=fondoprin, folder=False, isPlayable=False)
	plugintools.add_item(action="busca_comic",url="",title="[COLOR white]-Modificar Un Comic[/COLOR]", extra="modif", thumbnail="https://i.imgur.com/mu4AExB.png", fanart=fondoprin, folder=True, isPlayable=False)
	plugintools.add_item(action="busca_comic",url="",title="[COLOR white]-Borrar Un Comic[/COLOR]", extra="borrar", thumbnail="https://i.imgur.com/hxxkLOU.png", fanart=fondoprin, folder=True, isPlayable=False)
	plugintools.add_item(action="almacena_lista",url="",title="[COLOR white]-Almacenar Listas Externas[/COLOR]", extra="", thumbnail="https://i.imgur.com/pQXjvYV.png", fanart=fondoprin, folder=False, isPlayable=False)
	plugintools.add_item(action="agrega_lista0",url="",title="[COLOR white]-Anexar Comics Automáticamente desde una Lista Externa[/COLOR]", extra="", thumbnail="https://i.imgur.com/wFxTE98.png", fanart=fondoprin, folder=True, isPlayable=False)
	plugintools.add_item(action="cambia_lista0",url="",title="[COLOR white]-Sustituir Mi Lista de Comics Por Otra Externa[/COLOR]", extra="", thumbnail="https://i.imgur.com/rpPR6wI.png", fanart=fondoprin, folder=True, isPlayable=False)






	

def busca_comic(params):
	cabecera = params.get("title")
	fondo = params.get("fanart")
	extra = params.get("extra")
	logo0 = params.get("thumbnail")
	fondo = fondoprin
	
	plugintools.add_item(action="",url="",title=cabecera,thumbnail=logo0,fanart=fondo,folder=False,isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logo0, fanart=fondo, folder=False, isPlayable=False)

	plugintools.set_view(plugintools.TV_SHOWS)
	
	busqueda = plugintools.keyboard_input('', 'Introduzca [COLOR red]Título[/COLOR] o parte del Título a Buscar (Intro/Ok para Mostrar Todos)')
	
	if len(busqueda) == 0:  # Sacamos todas los Comics
		todas = True
	else:
		todas = False

	busqueda = busqueda.lower()
	
	fh = open(listaprin, "r")
	data = fh.read()
	fh.close()
	listas_orden=[]
	if todas == False:  # Empiezo la Busqueda
		if data.lower().find(busqueda) <> -1:
			comics = plugintools.find_multiple_matches(data,'<Line>(.*?)</Line>')
			
			#para que no exista desorden entre mayusculas y minusculas... pongo titulo en formato Title()
			
			for item in comics:
				titu = plugintools.find_single_match(item,'titu=(.*?)url=').strip()
				
				if busqueda in titu.lower():  # está la busqueda dentro del titulo, así q la agrego
					listas_orden.append(item.replace(titu, titu.title()))

	else:  # Las cojo todas
		comics = plugintools.find_multiple_matches(data,'<Line>(.*?)</Line>')
		
		#para que no exista desorden entre mayusculas y minusculas... pongo titulo en formato Title()
		
		for item in comics:
			titu = plugintools.find_single_match(item,'titu=(.*?)url=').strip()
			if len(titu) > 0:
				listas_orden.append(item.replace(titu, titu.title()))

	listas_orden.sort()
	
	popdata=open(fich_lista, "w+")

	for item2 in listas_orden:
		popdata.write(item2+"\n")

	popdata.close()

	
	puntero1 = 0
	paginacion(puntero1, extra,params)

	return
	


def paginacion(puntero1, extra,params):
	plugintools.set_view(plugintools.TV_SHOWS)
	puntero2 = puntero1 + 50
	
	popdata=open(fich_lista, "r")
	
	if extra == "modif":
		accion = "modif_comic"
		plugintools.add_item(action="",url="",title="[COLOR orange][B]****Modificar Comic****[/B][/COLOR]",thumbnail=logoprin, fanart=fondoprin, folder=False, isPlayable=False)
	elif extra == "borrar":
		accion = "borra_comic"
		plugintools.add_item(action="",url="",title="[COLOR orange][B]****Borrar Comic****[/B][/COLOR]",thumbnail=logoprin, fanart=fondoprin, folder=False, isPlayable=False)
	else:
		accion = "comics0"
			
	
	listas_orden=[]
	for linea in popdata.readlines():
		listas_orden.append(linea)

	popdata.close()

	total = len(listas_orden)
	if puntero2 > total:
		puntero2 = total
		
	letra = ""
	HaySinopsis = False
	while puntero1 < puntero2:
		item = listas_orden[puntero1]
		titu = plugintools.find_single_match(item,'titu=(.*?)url=').strip()
		url = plugintools.find_single_match(item,'url=(.*?)logo=').strip()

		logo = plugintools.find_single_match(item,'logo=(.*?)fondo=').strip()
		fondo = plugintools.find_single_match(item,'fondo=(.*?)sinop=').strip()
		if len(logo.strip()) == 0:
			logo = logoprin
		if len(fondo.strip()) == 0:
			fondo = fondoprin
			
		sinop = plugintools.find_single_match(item,'sinop=(.*)').strip()

		if len(sinop) <> 0:
			HaySinopsis = True
		
		if titu[:1] <> letra:
			letra = titu[:1]
			
			plugintools.add_item(action="",url="",title="[COLOR blue][I]**"+letra+"**[/I][/COLOR]",thumbnail=logoprin, fanart=fondoprin, extra=sinop, folder=False, isPlayable=False)
			
		datamovie = {}
		datamovie["Plot"]=sinop

		if extra == "modif":
			accion = "modif_comic"
		elif extra == "borrar":
			accion = "borra_comic"
		else:
			accion = "comics0"
			
		if len(titu) > 0 and len(url) == 0:  ## Doy x sentado q es un comentario y lo cambio de Color
			plugintools.add_item(action=accion, title = '[COLOR lime][B]' + titu + '[/B][/COLOR]', url = url  , extra = extra , info_labels = datamovie, thumbnail = logo , fanart = fondo , folder = True , isPlayable = False)
		else:
			plugintools.add_item(action=accion, title = '[COLOR white]' + titu + '[/COLOR]', url = url  , extra = extra , info_labels = datamovie, thumbnail = logo , fanart = fondo , folder = True , isPlayable = False)
		
		puntero1 = puntero1 + 1

	if puntero1 < total:
		datamovie = {}
		datamovie["Plot"]="Ir a la Siguiente Página..."
		punterotext = str(puntero1)
		plugintools.add_item(action="pagina_mas", title = '[COLOR green]·····Página Siguiente >>>>>[/COLOR]', url = ""  ,extra = extra , page = punterotext, thumbnail = "https://i.imgur.com/YnDpFtQ.png" , info_labels = datamovie,fanart = fondoprin , folder = True , isPlayable = False)

	if puntero1 > 50:
		datamovie = {}
		datamovie["Plot"]="Volver al Menú Principal..."
		punterotext = str(puntero1)
		plugintools.add_item(action="volver", title = '[COLOR red]·····Menú Principal >>>>>>>>[/COLOR]', url = ""  , extra = extra , page = punterotext, thumbnail = "https://i.imgur.com/MsOT5CR.png" , info_labels = datamovie,fanart = fondoprin , folder = True , isPlayable = False)

	
	plugintools.set_view(plugintools.TV_SHOWS)

	
	
def pagina_mas(params):
	puntero0  = params.get("page")
	extra  = params.get("extra")
	puntero1 = int(puntero0)
	
	paginacion(puntero1, extra, params)


def volver(params):

	plugintools.set_view(plugintools.TV_SHOWS)
	main_list(params)
	plugintools.set_view(plugintools.TV_SHOWS)
	return

	
	
	
	
	
def borratmp(params):
	try:
		#os.removedirs(temp)
		shutil.rmtree(temp, ignore_errors=False, onerror=None)
		xbmcgui.Dialog().ok( "¡¡Correcto!!" , "Todas las carpetas y subcarpetas temporales han sido Eliminadas." )
	except:
		xbmcgui.Dialog().ok( "¡¡Error!!" , "No se ha podido Eliminar. Pruebe mas tarde o elimine de forma manual la carpeta [COLOR red][B]...userdata/playlists/tmp[/B][/COLOR]" )


	
def agrega_comic(params):

	titulo = plugintools.keyboard_input('', 'Introduzca [COLOR red]Título[/COLOR] del Comic')
	url = plugintools.keyboard_input('', 'Introduzca [COLOR red]Link[/COLOR] de Descarga Directa')
	logo1 = plugintools.keyboard_input('', 'Introduzca [COLOR red]Url del Logo[/COLOR] del Comic')
	fondo1 = plugintools.keyboard_input('', 'Introduzca [COLOR red]Url del Fondo[/COLOR] del Comic')
	sinop = plugintools.keyboard_input('', 'Introduzca [COLOR red]Sinopsis[/COLOR] del Comic')
	
	url = url.replace("https://drive.google.com/open?id=" , "https://drive.google.com/uc?export=download&id=").replace("?dl=0" , "?dl=1")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	url = url.replace("https://drive.google.com/uc?export=download&id=" , "https://drive.google.com/uc?export=download&confirm=zf-t&id=")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox

	file_listas=open(listaprin, "a+")
	file_listas.write("<Line>titu="+titulo)
	file_listas.write(" url="+url)
	file_listas.write(" logo="+logo1)
	file_listas.write(" fondo="+fondo1)
	file_listas.write(" sinop="+sinop+"</Line>\n")

	file_listas.close()
	
	return
	
def agrega_lista0(params):
	logo = params.get("thumbnail")

	plugintools.add_item(action="abrealmacen", title = '[COLOR lime][B]Agregar Lista Desde Almacén de Listas[/B][/COLOR]', url = ""  , extra = "agrega" , thumbnail = "https://i.imgur.com/pQXjvYV.png" , fanart = fondoprin , folder = True, isPlayable = False)
	plugintools.add_item(action="agrega_lista", title = '[COLOR lime][B]Agregar Lista Introduciendo Link[/B][/COLOR]', url = ""  , extra = "" , thumbnail = logo , fanart = fondoprin , folder = False , isPlayable = False)


		
def agrega_lista(params):
	extra = params.get("extra")
	link = params.get("url")
	
	if extra == "almacen":
		url = link
	else:
		url = plugintools.keyboard_input('', 'Introduzca [COLOR red]Link[/COLOR] de Descarga Directa de la Nueva Lista.')

	if len(url) == 0:
		return
		
	url = url.replace("https://drive.google.com/open?id=" , "https://drive.google.com/uc?export=download&id=").replace("?dl=0" , "?dl=1")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	url = url.replace("https://drive.google.com/uc?export=download&id=" , "https://drive.google.com/uc?export=download&confirm=zf-t&id=")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	
	try:
		r=requests.get(url)
		data = r.content
	except:
		xbmcgui.Dialog().ok( "¡¡Error!!" , "No se ha podido descargar la Lista. Verifique el [COLOR red][B]Link[/B][/COLOR] y si es de Descarga Directa" )
		return
	
	titu_lista = plugintools.find_single_match(data,'titu_lista=(.*?)</Line>')
	logo_lista = plugintools.find_single_match(data,'logo_lista=(.*?)</Line>')
	autor = plugintools.find_single_match(data,'autor=(.*?)</Line>')
	
	lineas = plugintools.find_multiple_matches(data,'<Line>(.*?)/Line>')
	
	file_listas=open(listaprin, "r")
	data2 = file_listas.read()
	file_listas.close()
	
	file_listas=open(listaprin, "a+")
	c = 0
	for item in lineas:
		titu =  plugintools.find_single_match(item,'titu=(.*?)url=').strip()
		link = plugintools.find_single_match(item,'url=(.*?)logo=').strip()
		logo = plugintools.find_single_match(item,'logo=(.*?)fondo=').strip()
		fondo = plugintools.find_single_match(item,'fondo=(.*?)sinop=').strip()
		sinop = plugintools.find_single_match(item,'sinop=(.*?)<').strip()
		
		#if data2.find(titu) >= 0:  ## Ya existe en la lista actual
		if (titu in data2) == False and len(titu) > 0:  ## No existe en la lista actual así q lo anexo
			c = c + 1
			file_listas.write("<Line>titu="+titu)
			file_listas.write(" url="+link)
			file_listas.write(" logo="+logo)
			file_listas.write(" fondo="+fondo)
			file_listas.write(" sinop="+sinop+"</Line>\n\n")
	
	file_listas.close()
	xbmcgui.Dialog().ok( "Proceso Finalizado" , "Han sido añadidos "+str(c)+" Comics." )
		

		
def cambia_lista0(params):
	logo = params.get("thumbnail")

	plugintools.add_item(action="abrealmacen", title = '[COLOR lime][B]Agregar Lista Desde Almacén de Listas[/B][/COLOR]', url = ""  , extra = "cambia" , thumbnail = "https://i.imgur.com/pQXjvYV.png" , fanart = fondoprin , folder = True, isPlayable = False)
	plugintools.add_item(action="cambia_lista", title = '[COLOR lime][B]Agregar Lista Introduciendo Link[/B][/COLOR]', url = ""  , extra = "" , thumbnail = logo , fanart = fondoprin , folder = False , isPlayable = False)


		
def cambia_lista(params):
	extra = params.get("extra")
	link = params.get("url")
	
	if extra == "almacen":
		url = link
	else:
		url = plugintools.keyboard_input('', 'Introduzca [COLOR red]Link[/COLOR] de Descarga Directa de la Nueva Lista.')

	if len(url) == 0:
		return
		
	url = url.replace("https://drive.google.com/open?id=" , "https://drive.google.com/uc?export=download&id=").replace("?dl=0" , "?dl=1")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	url = url.replace("https://drive.google.com/uc?export=download&id=" , "https://drive.google.com/uc?export=download&confirm=zf-t&id=")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	
	try:
		r=requests.get(url)
		data = r.content
	except:
		xbmcgui.Dialog().ok( "¡¡Error!!" , "No se ha podido descargar la Lista. Verifique el [COLOR red][B]Link[/B][/COLOR] y si es de Descarga Directa" )
		return

	if os.path.exists(listacopia):  ## Si ya existe una copia anterior, la borro y genero la nueva
		os.remove(listacopia)
		os.rename(listaprin , listacopia)
	else:
		os.rename(listaprin , listacopia)
	
	file_listas=open(listaprin, "w+")
	file_listas.write(data)
	file_listas.close()

	xbmcgui.Dialog().ok( "Proceso Finalizado" , "La lista de Comics ha sido sustituida con éxito." , "Se ha generado una copia de la lista anterior en:" , "[COLOR lime][B]...userdata/addon-data/plugin.video.comics/copia_lista.txt[/COLOR][/B]" )
	

def abrealmacen(params):
	extra = params.get("extra")
	if extra == "cambia":
		accion = "cambia_lista"
	else:
		accion = "agrega_lista"
		
	file_listas=open(almacen, "r")
	data = file_listas.read()
	file_listas.close()
	
	listas = plugintools.find_multiple_matches(data,'<Line>(.*?)/Line>')
	if len(listas) == 0:
		xbmcgui.Dialog().ok( "El Almacén de Listas está Vacio" , "Tiene que Agregar Una o Varias Listas en la Opción del Menú [COLOR red]Almacenar Lista Externas[/COLOR]" )
		return
		
	for item in listas:
		titu =  plugintools.find_single_match(item,'titu=(.*?)url=').strip()
		link = plugintools.find_single_match(item,'url=(.*?)<').strip()
		link = link.replace("https://drive.google.com/open?id=" , "https://drive.google.com/uc?export=download&id=").replace("?dl=0" , "?dl=1")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
		link = link.replace("https://drive.google.com/uc?export=download&id=" , "https://drive.google.com/uc?export=download&confirm=zf-t&id=")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	
		plugintools.add_item(action=accion, title = '[COLOR wite][B]Lista: '+titu+'[/B][/COLOR]', url = link  , extra = "almacen" , thumbnail = "https://i.imgur.com/wCDgzqz.png" , fanart = fondoprin , folder = False, isPlayable = False)
	

	
	
def modif_comic(params):
	link1 = params.get("url")
	titu1 = params.get("title").replace("[COLOR white]" , "").replace("[COLOR lime]" , "").replace("[/COLOR]" , "").replace("[B]" , "").replace("[/B]" , "").title().strip()
	logo1 = params.get("thumbnail")
	fondo1 = params.get("fanart")

	file_listas=open(listaprin, "r")
	data = file_listas.read()
	file_listas.close()

	cada_comic = plugintools.find_multiple_matches(data,'Line>(.*?)/Line>')
	i = 0
	for item in cada_comic:
		titu =  plugintools.find_single_match(item,'titu=(.*?)url=').strip()
		link = plugintools.find_single_match(item,'url=(.*?)logo=').strip()
		logo = plugintools.find_single_match(item,'logo=(.*?)fondo=').strip()
		fondo = plugintools.find_single_match(item,'fondo=(.*?)sinop=').strip()
		sinop = plugintools.find_single_match(item,'sinop=(.*?)<').strip()
		
		if titu.lower() == titu1.lower() and link == link1 and logo == logo1 and fondo == fondo1:
			titu = plugintools.keyboard_input(titu, 'Introduzca [COLOR red]Título[/COLOR] del Comic')
			link = plugintools.keyboard_input(link, 'Introduzca [COLOR red]Link[/COLOR] de Descarga Directa')
			logo = plugintools.keyboard_input(logo, 'Introduzca [COLOR red]Url del Logo[/COLOR] del Comic')
			fondo = plugintools.keyboard_input(fondo, 'Introduzca [COLOR red]Url del Fondo[/COLOR] del Comic')
			sinop = plugintools.keyboard_input(sinop, 'Introduzca [COLOR red]Sinopsis[/COLOR] del Comic')
			
			link = link.replace("https://drive.google.com/open?id=" , "https://drive.google.com/uc?export=download&id=").replace("?dl=0" , "?dl=1")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
			link = link.replace("https://drive.google.com/uc?export=download&id=" , "https://drive.google.com/uc?export=download&confirm=zf-t&id=")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
			cada_comic[i]="titu="+titu
			cada_comic[i]=cada_comic[i]+" url="+link
			cada_comic[i]=cada_comic[i]+" logo="+logo
			cada_comic[i]=cada_comic[i]+" fondo="+fondo
			cada_comic[i]=cada_comic[i]+" sinop="+sinop+" <"
			
			break
			
		else:
			i = i + 1

	file_listas=open(listaprin, "w+")
	for item2 in cada_comic:
		if ("Line#>" in item2) == False:
			file_listas.write("<Line>"+item2+"/Line>\n\n")

	file_listas.write("<Line#>titu= url= logo= fondo= sinop= </Line>\n\n")
	file_listas.write("<Line#>titu= url= logo= fondo= sinop= </Line>\n\n")
	file_listas.write("<Line#>titu= url= logo= fondo= sinop= </Line>\n\n")
	file_listas.close()
	
	xbmcgui.Dialog().ok( "¡¡ATENCIÓN!!" , "La Modificación se ha Guardado Correctamente." )
	
	return
			





	
def borra_comic(params):
	link1 = params.get("url")
	titu1 = params.get("title").replace("[COLOR white]" , "").replace("[COLOR lime]" , "").replace("[/COLOR]" , "").replace("[B]" , "").replace("[/B]" , "").title().strip()
	logo1 = params.get("thumbnail")
	fondo1 = params.get("fanart")

	file_listas=open(listaprin, "r")
	data = file_listas.read()
	file_listas.close()

	cada_comic = plugintools.find_multiple_matches(data,'Line>(.*?)/Line>')
	i = 0
	for item in cada_comic:
		titu =  plugintools.find_single_match(item,'titu=(.*?)url=').strip()
		link = plugintools.find_single_match(item,'url=(.*?)logo=').strip()
		logo = plugintools.find_single_match(item,'logo=(.*?)fondo=').strip()
		fondo = plugintools.find_single_match(item,'fondo=(.*?)sinop=').strip()
		sinop = plugintools.find_single_match(item,'sinop=(.*?)<').strip()
		
		if titu.lower() == titu1.lower() and link == link1 and logo == logo1 and fondo == fondo1:

			eliminar = xbmcgui.Dialog().yesno("¡¡Atención!!", "Se va a eliminar el Comic [COLOR red]"+titu+"[/COLOR]" , "       ¿Confirma el Borrado?" )
			if eliminar:
				del(cada_comic[i])
			
			break
			
		else:
			i = i + 1

	if eliminar:
		file_listas=open(listaprin, "w+")
		for item2 in cada_comic:
			if ("Line#>" in item2) == False:
				file_listas.write("<Line>"+item2+"/Line>\n\n")

		file_listas.write("<Line#>titu= url= logo= fondo= sinop= </Line>\n\n")
		file_listas.write("<Line#>titu= url= logo= fondo= sinop= </Line>\n\n")
		file_listas.write("<Line#>titu= url= logo= fondo= sinop= </Line>\n\n")
		file_listas.close()
		
		xbmcgui.Dialog().ok( "¡¡ATENCIÓN!!" , "El Borrado se ha Realizado Correctamente." )
	
	return
			

def almacena_lista(params):
	titu = plugintools.keyboard_input("", 'Introduzca [COLOR red]Título[/COLOR] Para la Lista Externa')
	link = plugintools.keyboard_input("", 'Introduzca [COLOR red]Link[/COLOR] de Descarga Directa')

	link = link.replace("https://drive.google.com/open?id=" , "https://drive.google.com/uc?export=download&id=").replace("?dl=0" , "?dl=1")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	link = link.replace("https://drive.google.com/uc?export=download&id=" , "https://drive.google.com/uc?export=download&confirm=zf-t&id=")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
	file_listas=open(almacen, "a+")
	file_listas.write("<Line>titu="+titu)
	file_listas.write(" url="+link+"</Line>\n\n")
	
	file_listas.close()


def salida(params):

	xbmc.executebuiltin('ActivateWindow(10000,return)')
	



run()

		




	

