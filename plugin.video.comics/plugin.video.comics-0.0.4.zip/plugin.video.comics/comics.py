# -*- coding: utf-8 -*-
#---------------------------------------------------------------------
# Version 0.0.1 (30.04.2018)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)
# Gracias a la Idea General de PalcoTV

import os
import sys
import urllib
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import time

import zipfile  

import plugintools, requests
import resolvers
from __main__ import *


addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

version = "(v0.0.1)"

addonPath           = xbmcaddon.Addon().getAddonInfo("path")
mi_data = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.comics/'))
mi_addon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.comics'))
jpg = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.comics/jpg/'))
temp = xbmc.translatePath(os.path.join('special://home/userdata/playlists/tmp', ''))
playlists = xbmc.translatePath(os.path.join('special://home/userdata/playlists', ''))


if not os.path.exists(mi_data):
	os.makedirs(mi_data)  # Si no existe el directorio, lo creo
	
if not os.path.exists(temp):
	os.makedirs(temp)  # Si no existe el directorio, lo creo



cabecera = "[COLOR blue][B]              Visor De Comics  v0.0.1 [COLOR red]····[COLOR yellow]by Bad-Max[COLOR red]····[/B][/COLOR]"

def comics0(params):
    url = params.get("url")
    extra = params.get("extra")
    fanart = params.get("fanart")
    thumbnail = params.get("thumbnail")
    datamovie = {}
    datamovie["plot"] = params.get("plot")
    url_fixed = url.split("/");num_splits = int(len(url_fixed)) - 1
    title = params.get("title")
    if len(url) > 0:
        filename = title.replace(" " , "_").replace("[COLOR" , "").replace("[B]" , "").replace("[/B]" , "").replace("[I]" , "").replace("[/I]" , "").replace("[/COLOR]" , "")
        filename = filename.replace("[" , "").replace("]" , "").replace("{" , "").replace("}" , "").replace("ç" , "").replace("Ç" , "").replace("!" , "").replace("¡" , "")
        filename = filename.replace("'" , "").replace('"' , "").replace("|" , "").replace("@" , "").replace("·" , "").replace("$" , "").replace("~" , "").replace("%" , "")
        filename = filename.replace("€" , "").replace("&" , "").replace("¬" , "").replace("/" , "").replace("(" , "").replace(")" , "").replace("=" , "").replace("ª" , "")
        filename = filename.replace("º" , "").replace("?" , "").replace("¿" , "").replace("*" , "").replace("+" , "").replace("-" , "").replace(";" , "").replace("," , "")
        filename = filename.replace(":" , "").replace("." , "").replace("<" , "").replace(">" , "") + ".cbr"
        src_cbx = temp + filename
    else:
        return

    dst_folder = temp + filename.replace(".cbr" , "/")

    carpeta = xbmc.translatePath(os.path.join(dst_folder, ''))

    if os.path.exists(carpeta):  ## Si ya tengo de vez anterior descargado el fichero y descomprimido, no lo vuelvo a hacer
        page = 1
        plugintools.add_item(action="show_cbx", title="[COLOR orange][B]Ayuda: [/COLOR][COLOR white]Atajos de teclado[/B][/COLOR]", url="https://i.imgur.com/oFeIhQr.png", info_labels = datamovie , thumbnail = "https://i.imgur.com/oFeIhQr.png", fanart = fanart, folder=False, isPlayable=False)    
        plugintools.add_item(action="slide_cbx", title="[COLOR orange][B]Ver: [/COLOR][COLOR white]"+title+"[/B][/COLOR]", url=dst_folder, page=str(page), extra=dst_folder , info_labels = datamovie , thumbnail = thumbnail, fanart = fanart, folder=False, isPlayable=False)    
        return
    url = url.replace("https://drive.google.com/open?id=" , "https://drive.google.com/uc?export=download&id=").replace("?dl=0" , "?dl=1")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox
    url = url.replace("https://drive.google.com/uc?export=download&id=" , "https://drive.google.com/uc?export=download&confirm=zf-t&id=")  ## Para hacer el link de Descarga Automática en GoogleDrive y DropBox

    data = plugintools.read(url)
    fh = open(temp + filename, "wb")  #open the file for writing
    fh.write(data)
    fh.close()

    page = 1
    if src_cbx.endswith(".cbr") == True:  # Descompresión archivos
        try:  ## Con Formato Zip Puro
            zf=zipfile.ZipFile(src_cbx, "r")
            for i in zf.namelist():
                zf.extract(i, path=dst_folder)
 
        except:  ## Con Formato Rar
            try:
                xbmc.executebuiltin('XBMC.Extract('+src_cbx+','+dst_folder+')')
                xbmc.sleep(1000)
                plugintools.log("*************** DESDE RAR ************")

            except:  ## El fichero no tiene formatos Zip o Rar o está Corrupto
                xbmcgui.Dialog().ok( "¡¡Imposible Descomprimir Fichero!!" , "Verifique si el fichero está creado en Formatos Rar o Zip, o que no esté corrupto." )
                return

        thumbnail = params.get("thumbnail")
        if thumbnail == "":
            thumbnail = dst_folder+'\\00.jpg'
            if thumbnail == "":
                thumbnail = 'http://ww1.prweb.com/prfiles/2010/07/13/3676844/Slideshow512.png'        
        fanart = dst_folder+'\\00.jpg'
        plugintools.log("fanart1= "+fanart)
        if fanart == "":
            fanart = dst_folder+'\\00.jpg'
            plugintools.log("fanart2= "+fanart)
            if fanart == "":
                fanart = art+'slideshow.png'
                plugintools.log("fanart3= "+fanart)

    plugintools.add_item(action="show_cbx", title="[COLOR orange][B]Ayuda: [/COLOR][COLOR white]Atajos de teclado[/B][/COLOR]", url="https://i.imgur.com/oFeIhQr.png", info_labels = datamovie , thumbnail = "https://i.imgur.com/oFeIhQr.png", fanart = fanart, folder=False, isPlayable=False)    
    plugintools.add_item(action="slide_cbx", title="[COLOR orange][B]Ver: [/COLOR][COLOR white]"+title+"[/B][/COLOR]", url=dst_folder, page=str(page), extra=dst_folder , info_labels = datamovie , thumbnail = thumbnail, fanart = fanart, folder=False, isPlayable=False)    


	
def slide_cbx(params):
    url = params.get("url")
    carpeta = params.get("extra")
    page = params.get("page")
    plugintools.log("url= "+url)

    #v0.0.3 (24-05-18) Para facilitar el trabajo al usuario final... tras comprobar que la mayoría de .cbr, .cbx, .rar y .zip que descargamos
    #no vienen con un formato correcto (Las Imágenes en el raiz del comprimido, si no que muuuchas veces traen una carpeta intermedia)
    #Para evitar que el usuario tenga que descomprimir, eliminar la carpeta intermedia y volver a comprimir, procuro resolverlo mediante código.
    #contenido = os.scandir(carpeta)
    imagenes = False
    for ruta, directorios, archivos in os.walk(carpeta, topdown=True):
        #plugintools.log("***********Ruta Leida1= "+ruta)
        for elemento in archivos:
            #plugintools.log("***********Elemento Fichero= "+elemento)
            if (".jpg" in elemento) or (".jpeg" in elemento) or (".png" in elemento):  ## Doy por supuesto que al haber imágenes, estoy en el "raiz" correcto y no sigo
                imagenes = True
                carpeta = xbmc.translatePath(os.path.join(ruta, ''))
                break
        if imagenes:
            break

    if not imagenes:  ## Si no hay ni Imagenes ni Carpetas, hay un error en el contenido del fichero comprimido
        xbmcgui.Dialog().ok( "¡¡Imposible Leer Fichero!!" , "Verifique si el fichero está Vacio, o que no esté Corrupto." )
        return

    page_to_start = carpeta + '\\'+str(page)
    xbmc.executebuiltin( "SlideShow("+carpeta+",pause," +page+")" )
    


def show_cbx(params):
    url = params.get("url")
    dst_folder = params.get("extra")
    page = params.get("page")
    plugintools.log("url= "+url)
    page_to_start = dst_folder + '\\'+str(page)    
    xbmc.executebuiltin( "ShowPicture("+url+")" )    
    

def show_image(params):
    url=params.get("url")

    h=urllib2.HTTPHandler(debuglevel=0)  # Iniciamos descarga...
    request = urllib2.Request(url)
    opener = urllib2.build_opener(h)
    urllib2.install_opener(opener)
    filename = url.split("/")
    max_len = len(filename)
    max_len = int(max_len) - 1
    filename = filename[max_len]
    fh = open(temp + filename, "wb")  #open the file for writing
    connected = opener.open(request)
    meta = connected.info()
    filesize = meta.getheaders("Content-Length")[0]
    size_local = fh.tell()
    while int(size_local) < int(filesize):
        blocksize = 100*1024
        bloqueleido = connected.read(blocksize)
        fh.write(bloqueleido)  # read from request while writing to file
        size_local = fh.tell()
    imagen = temp + filename
    xbmc.executebuiltin( "ShowPicture("+imagen+")" )  


class ziptools:

    def extract(self, file, dir, params):
        plugintools.log("file=%s" % file)

        dir = addons        
        if not dir.endswith(':') and not os.path.exists(dir):
            os.mkdir(dir)

        zf = zipfile.ZipFile(file)
        self._createstructure(file, dir)
        num_files = len(zf.namelist())

        for name in zf.namelist():
            plugintools.log("name=%s" % name)
            if not name.endswith('/'):
                plugintools.log("no es un directorio")
                plugintools.log("dst_folder= "+dir)                                
                try:
                    (path,file) = os.path.split(os.path.join(dir, name))
                    plugintools.log("path=%s" % path)
                    plugintools.log("name=%s" % name)
                    os.makedirs( path )
                except:
                    pass
                outfilename = os.path.join(dir, name)
                plugintools.log("outfilename=%s" % outfilename)
                try:
                    outfile = open(outfilename, 'wb')
                    outfile.write(zf.read(name))
                except:
                    plugintools.log("Error en fichero "+name)
