import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL21hdmVyaWNrdHYubmV0L2RhdGEvc3BvcnRzL3Nwb3J0cy54bWw=')
addon = xbmcaddon.Addon('plugin.video.ProjectMayhem')