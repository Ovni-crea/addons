MAX_STR_LENGTH = 300  # characters
RAW_OUTPUT = False
