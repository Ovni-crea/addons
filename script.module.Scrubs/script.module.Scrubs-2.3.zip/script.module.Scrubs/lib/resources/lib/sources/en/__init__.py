# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 11-13-2018 by JewBMX in Scrubs.

# xbmcgui.Dialog ().textviewer ("data",str (name))

# from resources.lib.modules import cfscrape
# scraper = cfscrape.create_scraper()
# r = scraper.get(url).content

import os.path

files = os.listdir(os.path.dirname(__file__))
__all__ = [filename[:-3] for filename in files if not filename.startswith('__') and filename.endswith('.py')]
