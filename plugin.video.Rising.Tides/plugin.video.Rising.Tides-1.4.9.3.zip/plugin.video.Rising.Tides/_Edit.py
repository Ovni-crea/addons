import xbmcaddon

MainBase = 'http://bit.ly/RTNEWHOMEEE'
addon = xbmcaddon.Addon('plugin.video.Rising.Tides')