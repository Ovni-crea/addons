import xbmcaddon

MainBase = 'http://bit.ly/HOMEPEM11'
addon = xbmcaddon.Addon('plugin.video.Rising.Tides')