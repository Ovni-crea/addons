from resources.lib.externals.hachoir.hachoir_parser.game.zsnes import ZSNESFile
from resources.lib.externals.hachoir.hachoir_parser.game.spider_man_video import SpiderManVideoFile
from resources.lib.externals.hachoir.hachoir_parser.game.laf import LafFile
from resources.lib.externals.hachoir.hachoir_parser.game.blp import BLP1File, BLP2File