import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.bangonpinoy'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'Bangon Pinoy'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"


BASEURL = 'https://pinoymoviepedia.org'
BASEURL2 = 'http://watchpinoymoviesonline.info/'
BASEURL3 = 'http://www.kapuso.be/'


def MENU():
    xbmcgui.Dialog().ok("Bangon Pinoy", "Gawang pinoy Tubong La Union", "ALLAN.CA")
    addDir('[B][COLOR white]ABS-CBN KAPAMILYA[/COLOR][/B]','http://pacitalaflakes.blogspot.com/search/label/ABS-CBN?m=0',4,ART + 'kapamilya.jpg',FANART,'')
    addDir('[B][COLOR white]GMA KAPUSO[/COLOR][/B]',BASEURL3 + 'search/label/GMA?&max-results=24',4,ART + 'gmakapuso.jpg',FANART,'')
    addDir('[B][COLOR white]LAMBINGAN[/COLOR][/B]','http://www.lambingan.su/',7,ART + 'TAMBAYAN.JPG',FANART,'')
    addDir('[B][COLOR white]FILIPINO MOVIES[/COLOR][/B]','url',2,ART + 'pinoymov.jpg',FANART,'')
    addDir('[B][COLOR white]HOLLYWOOD MOVIES[/COLOR][/B]','url',3,ART + 'hmov.jpg',FANART,'')
    addDir('[B][COLOR white]Asian Movies[/COLOR][/B]',BASEURL+'/category/asian-movies/',13,ART + 'asian.jpg',FANART,'')
    addDir('[B][COLOR white]TAGALOG-DUBBED[/COLOR][/B]',BASEURL2+'category/tagalog-dubbed/',6,ART + 'TAGALOGDUB.jpg',FANART,'')
    addDir('[B][COLOR white]P.B.A.[/COLOR][/B]','https://pbafullreplay.blogspot.ae/',10,ART + 'PBA.png',FANART,'')
    setView('tvshows', 'tvshows-view')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<a class='thumbx' href='(.+?)' title='(.+?)'.+?src='(.+?)'/></a>",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        icon = icon.replace('s72-c/','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,icon,FANART,'')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'kapuso' in url:
            icon = ART + 'nextpagekap.jpg'
        if 'pacitalaflakes' in url:
            icon = ART + 'nextpagetamb.jpg'
        addDir('[B][COLOR red]Older Posts>>>[/COLOR][/B]',url,4,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        addDir('%s' %name2,url,16,iconimage,iconimage,name)
    altlinks = re.compile('id="tabs.+?src="(.+?)".+?allowfullscreen',re.DOTALL).findall(OPEN)
    i=1
    for url in altlinks:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        if len(altlinks)>1:
            name1= name2 + ' - Part '+ str(i)
            i=i+1
            addDir('%s' %name1,url,16,iconimage,iconimage,name)
        else:
            addDir(name2,url,16,iconimage,iconimage,name)
        # addDir('%s Part' %name2,'http://www.dailymotion.com/embed/video/%s'%url,16,iconimage,FANART,name)
    linkView()


#tagalog movies#
def pinoyonlinemenu():
    addDir('[B][COLOR white]Latest Movies 1[/COLOR][/B]','https://pinoymoviepedia.org/category/tagalog-movies/',13,ART + 'FILMOVS.jpg',FANART,'')
    addDir('[B][COLOR white]Latest Movies 2[/COLOR][/B]',BASEURL2+'category/latest/',6,ART + 'FILMOVS.jpg',FANART,'')
    setView('tvshows', 'cat-view')

def Mov_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('div id="content" role="main">(.+?)<!-- end #content -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,16,icon,ART + 'fanart2.jpg','')
    np = re.compile('rel="next".+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,6,ART + 'n_p.png',ART + 'fanart2.jpg','')
    setView('tvshows', 'default-view') 

#pinoymoviepedia#
def moviechannel():
    addDir('[B][COLOR white]Hollywood Movies[/COLOR][/B]',BASEURL+'/category/hollywood-movies/',13,ART + 'eng-mov.png',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Hollywood Bluray[/COLOR][/B]',BASEURL+'/category/bluray/',13,ART + 'bluray.png',ART + 'fanart2.jpg','')
    setView('tvshows', 'cat-view')
    
def pinoypedia_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<li class="border-radius.+?src="(.+?)".+?href="(.+?)" title="(.+?)">',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        icon = icon.replace('-210x142','').replace('-199x142','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,15,icon,ART + 'fanart2.jpg','')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page >>>[/COLOR][/B]',url,13,ART + 'n_p2.png',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)') 
    
def pinoypedia_links(name,url):
    OPEN = Open_Url(url)
    Links = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)
    i=1
    for url in Links:
        url = url.replace('https://href.li/?','')
        if urlresolver.HostedMediaFile(url).valid_url():
			try:
				name2 = url.split('//')[1].replace('www.','')
				name2 = name2.split('/')[0].split('.')[0].title()
			except:pass
			addDir(name2,url,16,iconimage,iconimage,name)
        elif len(Links)>1:		
			name1= 'Movie Link '+ str(i)
			i=i+1
			addDir('%s' %name1,url,16,iconimage,iconimage,name)
    linkView()

def pedia_Search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL + '/?s=' + search
            pinoypedia_content(url)

#P.B.A.#
def PBA_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<div class='post-outer'>.+?<meta content='(.+?)' itemprop='image_url'.+?href='(.+?)'>(.+?)</a>.+?trbidi=.+?on.+?>(.+?)<br>",re.DOTALL).findall(OPEN) 
    for icon,url,name,description in Regex:
        description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&').replace('&amp;','&').replace('<div dir="ltr"','').replace(' style="text-align: left;"','').replace(' trbidi="on">','').replace('<br>','').replace('','').replace('<div class="separator" style="clear: both; text-align: center;">','')
        addDir('%s' %name,url,11,icon,icon,description)
    tp = re.compile("<a class='home-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in tp:
        addDir('[B][COLOR lime]Top Page[/COLOR][/B]',url,10,ART + 'pbareplay.jpg',ART + 'pba.jpg','')
    pp = re.compile("<a class='blog-pager-newer-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in pp:
        addDir('[B][COLOR lime]Previous Page[/COLOR][/B]',url,10,ART + 'pbareplay.jpg',ART + 'pba.jpg','')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page[/COLOR][/B]',url,10,ART + 'pbareplay.jpg',ART + 'pba.jpg','')
    linkView()

def PBA_links(name,url):
	OPEN = Open_Url(url)
	Regex = re.compile("1ST QUARTER(.+?)<div class='post-footer'>",re.DOTALL).findall(OPEN)
	match = re.compile('<iframe.+?src="(.+?)".+?</iframe>',re.DOTALL).findall(str(Regex))	
	if match:
		i=0
		for url in match:
			if 'dailymotion' in match:
				url = 'http:' + url
			else:
				url = url
			if len(match) >1:
				i +=1
				label=i
				name2 = '[B][COLOR lime]%s QUARTER[/COLOR][/B]' %label
				name2 = name2.replace('1','1ST').replace('2','2ND').replace('3','3RD').replace('4','4TH').replace('5 QUARTER','1ST OVERTIME').replace('6 QUARTER','2ND OVERTIME').replace('7 QUARTER','3RD OVERTIME')
				addDir('%s' %name2,url,16,iconimage,iconimage,name)
			else:
				addDir(name,url,16,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
	linkView()

def PBA_RESOLVE(url):
    hosts = []
    stream_url = []
    host = ''
    try:
        OPEN = Open_Url(url)
        count = 0
        links = re.compile("1ST QUARTER(.+?)<div class='post-footer'>",re.DOTALL).findall(OPEN)
        match = re.compile('<iframe.+?src="(.+?)".+?</iframe>',re.DOTALL).findall(str(links))
        for link in match:
                count +=1 
                label = count
                host = '[B][COLOR lime]%s QUARTER[/COLOR][/B]' %label				
                host= host.replace('1','1ST').replace('2','2ND').replace('3','3RD').replace('4','4TH').replace('5 QUARTER','1ST OVERTIME').replace('6 QUARTER','2ND OVERTIME').replace('7 QUARTER','3RD OVERTIME')				
                hosts.append(host)
                stream_url.append(link)
        if len(match) >1:
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Please Select Quarter',hosts)
                if ret == -1:
                    return
                elif ret > -1:
                        url = stream_url[ret]
        else:
            url = re.compile('iframe.+?src="(.+?)"').findall(OPEN)[0]
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR cornflowerblue]No Links Available[/COLOR] ,5000)")
    url = 'http:' + url  
    try:    
        stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

#lambingan#
def lamb_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('div class="item post.+?href="(.+?)".+?rel="(.+?)".+?alt="(.+?)".+?<p>(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,icon,name,description in Regex:
        if 'http' not in icon:
            icon = 'http:' + icon
            icon = icon.replace('-549x316_c','')
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        description = description.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"').replace('&#8212;','--').replace('&#8206;',' ').replace('&nbsp;',' ')
        addDir('%s' %name,url,8,icon,icon,description)
    np = re.compile("rel='next' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'http' not in url:
            url = 'http:' + url
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,7,ART + 'page.jpg',FANART,'')
    setView('episodes', 'epi-view')     
    
def lamb_vids(name,url):
    OPEN = Open_Url(url)
    i=1
    Regex = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
		if 'http' not in url:
			url = 'http:' + url
		if not 'facebook' in url:
			name2= 'Video Link ' + str(i)
			i=i+1
			addDir('%s' %name2,url,67,iconimage,iconimage,name)			
				
    linkView()

def lamb_res(url):
    if 'http' not in url:
        url = 'http:' + url
    if 'watchnew' in url:
        OPEN = Open_Url(url)
        try:
            url = re.compile('<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)[0]
            if 'http:' not in url:
                url = 'http:' + url
                stream_url = urlresolver.resolve(url)
            else:
                stream_url = urlresolver.resolve(url)
        except:
            url = re.compile('<div class=.+?container.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
    elif 'linkshare' in url:
		OPEN = Open_Url(url)
		url = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)[0]
		stream_url = url
    # elif 'dailymotion' in url:
		# url = 'http:' + url
		# stream_url = urlresolver.resolve(url)
    elif 'libangan' in url:
        Holder = Open_Url(url)
        if '/dm' in url:
            try:
				url = re.compile('"file": "(.+?)"',re.DOTALL).findall(Holder)[0]
				stream_url = url
            except:
				url = re.compile('class="bio".+?src="(.+?)"',re.DOTALL).findall(Holder)[0]
				if 'dailymotion' in url:
					url = 'http:' + url
					stream_url = urlresolver.resolve(url)
				elif 'linkshare' in url:
					OPEN = Open_Url(url)
					url = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)[0]
					stream_url = url
        elif '/embed-videoza' in url:
            url = re.compile('<a href="(.+?)".+?img border',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/embed-streamango' in url:
            url = re.compile('<a href="(.+?)".+?img border',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/embed-ok' in url:
            url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif 'ok.ru/videoembed' in url:
            stream_url = urlresolver.resolve(url)
        else:
			url = re.compile('<a href="(.+?)".+?img border',re.DOTALL).findall(Holder)[0]
			stream_url = urlresolver.resolve(url)
    else:
        stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

#res#   
def RESOLVE(url):
    try:
        if 'speedvid.net' in url:
            OPEN = Open_Url(url)
            link = re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|',re.DOTALL).findall(OPEN)
            for port,server,hash in link:
                url = 'http://'+ server +'.speedvid.net:'+port+'/'+hash+'/v.mp4'
            stream_url=url
        elif 'watchpinoymoviesonline.info' in url:
            OPEN = Open_Url(url)
            url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        elif 'pinoymovieshub' in url:
            OPEN = Open_Url(url)
            url = re.compile('class="boton reloading".+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        elif 'pinoymovies.stream' in url:
            OPEN = Open_Url(url)
            url = re.compile('class="metaframe rptss" src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        elif 'linkshare.tv' in url:
            OPEN = Open_Url(url)
            url = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = url
        elif 'relaxpinas' in url:
            OPEN = Open_Url(url)
            Regex = re.compile('var playlis(.+?)];',re.DOTALL).findall(OPEN)
            url = re.compile("'(.+?)'").findall(str(Regex))[0]
            stream_url = url			
        elif 'freepinoytvshows' in url:
            OPEN = Open_Url(url)
            url = re.compile('source: "(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = url
        elif 'vidio.com' in url:
            stream_url = url
        elif 'nodefiles.com' in url:
            stream_url = url
        elif 'streamable.com' in url:
            stream_url = url
        elif 'bit.ly' in url:
            OPEN = Open_Url(url)
            url = re.compile('"og:url" content="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        elif 'archive' in url:
            OPEN = Open_Url(url)
            url = re.compile('"og:video" content="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = url
        else:
			if urlresolver.HostedMediaFile(url).valid_url():
				stream_url = urlresolver.resolve(url)
			else:
				stream_url = url
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)") 

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==16 or mode==9 or mode==12:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
		
def linkView():
	xbmcplugin.setContent(int(sys.argv[1]), 'files')
    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
playlist=None
regexs=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass
try:
    playlist=eval(urllib.unquote_plus(params["playlist"]).replace('|',','))
except:
    pass
try:
    regexs=params["regexs"]
except:
    pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 2 : pinoyonlinemenu()
elif mode == 3 : moviechannel()
elif mode == 4 : Get_content(url) 
elif mode == 5 : Get_links(name,url)
elif mode == 6 : Mov_Menu(url)
elif mode == 7 : lamb_content(url)
elif mode == 8 : lamb_vids(name,url)
elif mode == 9 : lamb_res(url)
elif mode == 10 : PBA_content(url)
elif mode == 11 : PBA_links(name,url)
elif mode == 12 : PBA_RESOLVE(url)
elif mode == 13 : pinoypedia_content(url)
elif mode == 14 : pedia_Search()
elif mode == 15 : pinoypedia_links(name,url)
elif mode == 16 : RESOLVE(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))