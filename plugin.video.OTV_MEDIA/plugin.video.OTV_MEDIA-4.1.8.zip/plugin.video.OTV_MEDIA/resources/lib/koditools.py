#	-*-	coding:	utf-8	-*-
from urllib2 import Request, URLError, urlopen as urlopen2
from socket import gaierror, error
from resources.lib.gui.guiElement import cGuiElement
import re, httplib, urllib, urllib2, os, cookielib, socket, sha, shutil, datetime, math, hashlib, random, json, md5, string, xml.etree.cElementTree, StringIO, Queue, threading, sys
from urllib import quote, unquote_plus, unquote, urlencode
from urlparse import parse_qs, parse_qsl
iconimage=None
import base64
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
import common
import re
import string
#from aadecode import AADecoder
from parser import JJDecoder
from parser import cPacker
import re,xbmcgui,unicodedata
import urllib2,urllib,re,HTMLParser,cookielib
import sys,os,base64,time
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from resources.lib.aadecode import decode as aadecode

import unwise
import re, cookielib, time, xbmcgui, xbmc, os, urllib2
from urllib2 import Request, URLError, urlopen as urlopen2
from urlparse import parse_qs
from urllib import quote, urlencode, unquote_plus, unquote
from httplib import HTTPConnection, CannotSendRequest, BadStatusLine, HTTPException
from socket import gaierror, error
from t0mm0.common.net import Net
from jsunpacker import cJsUnpacker
from resources.lib.gui.gui import cGui
from resources.lib.util import cUtil,VSlog
from resources.lib.parser import cParser
from resources.lib.handler.requestHandler import cRequestHandler
import requests
import re
net = Net()
import jsunpack
import logger     

from httpkir import httptools,scrapertools
SITE_IDENTIFIER = 'youtubecom_tr'
SITE_NAME = 'koditools'
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
def _get(request,post=None):
    """Performs a GET request for the given url and returns the response"""
    return opener.open(request,post).read()
def unescape(src):
    s = src.decode('string-escape')
    u = s.decode('utf8')
    
    return u.encode('unicode-escape')
def waitmsg(sec, msg):
		isec = int(sec)
		if isec > 0:
			dialog = xbmcgui.DialogProgress()
			dialog.create('Resolving', '%s Link.. Wait %s sec.' % (msg, sec))
			dialog.update(0)
			c = 100 / isec
			i = 1
			p = 0
			while i < isec+1:
				p += int(c)
				time.sleep(1)
				dialog.update(int(p))
				i += 1
			dialog.close()


import re

def check_url(url):
    import urlparse
    parts = urlparse.urlsplit(url)
    if not parts.scheme or not parts.netloc:
        return False
    else:
        return True
from  rutrans import detranslify
def alfabekodla(text):
        text = (str(text)).replace('0xc3','.')
       
        text = (str(text)).replace('\\x','')
        text = (str(text)).replace('&auml;','ä')
	text = (str(text)).replace('\u00e4','ä')
	text = (str(text)).replace('\ufeff','ä')
        text = (str(text)).replace('&#228;','ä')
	text = (str(text)).replace('&Auml;','Ä')
	text = (str(text)).replace('\u00c4','Ä')
	text = (str(text)).replace('&#196;','Ä')
	text = (str(text)).replace('&ouml;','ö')
	text = (str(text)).replace('\u00f6','ö')
	text = (str(text)).replace('&#246;','ö')
	text = (str(text)).replace('&ouml;','Ö')
	text = (str(text)).replace('&Ouml;','Ö')
	text = (str(text)).replace('\u00d6','Ö')
	text = (str(text)).replace('&#214;','Ö')
	text = (str(text)).replace('&uuml;','ü')
	text = (str(text)).replace('\u00fc','ü')
	text = (str(text)).replace('&#252;','ü')
	text = (str(text)).replace('&Uuml;','Ü')
	text = (str(text)).replace('\u00dc','Ü')
	text = (str(text)).replace('&#220;','Ü')
        text = (str(text)).replace('tv_','player')
	text = (str(text)).replace('&szlig;','ß')
	text = (str(text)).replace('\u00df','ß')
	text = (str(text)).replace('&#223;','ß')
	text = (str(text)).replace('&amp;','&')
	text = (str(text)).replace('&quot;','\"')
	text = (str(text)).replace('&gt;','>')
	text = (str(text)).replace('&apos;',"'")
	text = (str(text)).replace('&acute;','\'')
	text = (str(text)).replace('&ndash;','-')
	text = (str(text)).replace('&bdquo;','"')
	text = (str(text)).replace('&rdquo;','"')
	text = (str(text)).replace('&ldquo;','"')
	text = (str(text)).replace('&lsquo;','\'')
	text = (str(text)).replace('&rsquo;','\'')
	text = (str(text)).replace('&#034;','\'')
	text = (str(text)).replace('&#038;','&')
	text = (str(text)).replace('&#039;','\'')
	text = (str(text)).replace('&#39;','\'')
	text = (str(text)).replace('&#160;',' ')
	text = (str(text)).replace('\u00a0',' ')
	text = (str(text)).replace('\u00b4','\'')
	text = (str(text)).replace('&#174;','')
	text = (str(text)).replace('&#225;','a')
	text = (str(text)).replace('&#233;','e')
	text = (str(text)).replace('&#243;','o')
	text = (str(text)).replace('&#8211;',"-")
	text = (str(text)).replace('\u2013',"-")
	text = (str(text)).replace('&#8216;',"'")
	text = (str(text)).replace('&#8217;',"'")
	text = (str(text)).replace('&#8220;',"'")
	text = (str(text)).replace('&#8221;','"')
	text = (str(text)).replace('&#8222;',',')
	text = (str(text)).replace('\u201e','\"')
	text = (str(text)).replace('\u201c','\"')
	text = (str(text)).replace('\u201d','\'')
	text = (str(text)).replace('\u2019s','\'')
	text = (str(text)).replace('\u00e0','à')
	text = (str(text)).replace('\u00e7','ç')
	text = (str(text)).replace('\u00e9','é')
	text = (str(text)).replace('&#xC4;','Ä')
	text = (str(text)).replace('&#xD6;','Ö')
	text = (str(text)).replace('&#xDC;','Ü')
	text = (str(text)).replace('&#xE4;','ä')
	text = (str(text)).replace('&#xF6;','ö')
	text = (str(text)).replace('&#xFC;','ü')
	text = (str(text)).replace('&#xDF;','ß')
	text = (str(text)).replace('&#xE9;','é')
	text = (str(text)).replace('&#xB7;','·')
	text = (str(text)).replace("&#x27;","'")
	text = (str(text)).replace("&#x26;","&")
	text = (str(text)).replace("&#xFB;","û")
	text = (str(text)).replace("&#xF8;","ø")   
	text = (str(text)).replace("&#x21;","!")                          
	text = (str(text)).replace("&#x3f;","?")
        text = (str(text)).replace("&#304;",  "I")       
        text = (str(text)).replace("&#304;",  "I")
        text = (str(text)).replace("&#39;", "'")
        text = (str(text)).replace('&#39;',"ş")
	text = (str(text)).replace('&#8230;','...')
	text = (str(text)).replace('\u2026','...')  
	text = (str(text)).replace('c59f','ş')
	text = (str(text)).replace('c4b1','ı')
        text = (str(text)).replace('c3b6','ö')
        text = (str(text)).replace('c3bc','ü')                    
        text = (str(text)).replace('c387','Ç')
        text = (str(text)).replace('c3a7','ç')
        text = (str(text)).replace('c396','Ö')
        text = (str(text)).replace('&#8234;','')
	text = (str(text)).replace("&#39;", "'")
        text = (str(text)).replace('&#39;',"ş")
	text = (str(text)).replace('&#8230;','...')
	text = (str(text)).replace('\u2026','...')
	text = (str(text)).replace('&hellip;','...')
	text = (str(text)).replace('&#8234;','')
        text = (str(text)).replace("&#231;", "ç")
        text = (str(text)).replace('&#351;',"ş")
	text = (str(text)).replace('&#350;','ş')
	text = (str(text)).replace('&#246;','ö')
	text = (str(text)).replace('&#214;','Ö')
	text = (str(text)).replace('&#199;','Ç')
        text = (str(text)).replace("0x99","?").replace('\xc2\xa0',' ').replace('\xc3\xa7','c').replace('\xe2\x80\x93',' - ').replace('\xc4\xb1','i').replace('\xc3\xb6','o').replace('xc3\xbc','u').replace('xc5\x9f','s').replace('\xc5\x9e','S').replace('xc4\x9f','g').replace('\xc3\x87','C').replace('\xc3\x96','O').replace('\xc3\x9c','U').replace('\xc2\xa1','¡').replace('\xc2\xa2','¢').replace('&#039;','`').replace('\xc2\xa3','£').replace('\xc2\xa4','¤').replace('\xc2\xa5','¥').replace('\xc2\xa6','¦').replace('\xc2\xa7','§').replace('\xc2\xa8','¨').replace('\xc2\xa9','©').replace('\xc2\xaa','ª').replace('\xc2\xab','«').replace('\xc2\xac','¬').replace('\xc2\xad','­').replace('\xc2\xae','®').replace('\xc2\xaf','¯').replace('\xc2\xb0','°').replace('\xc2\xb1','±').replace('\xc2\xb2','²').replace('\xc2\xb3','³').replace('\xc2\xb4','´').replace('\xc2\xb5','µ').replace('\xc2\xb6','¶').replace('\xc2\xb7','·').replace('\xc2\xb8','¸').replace('\xc2\xb9','¹').replace('\xc2\xba','º').replace('\xc2\xbb','»').replace('\xc2\xbc','¼').replace('\xc2\xbd','½').replace('\xc2\xbe','¾').replace('\xc2\xbf','¿').replace('\xc3\x80','À').replace('\xc3\x81','Á').replace('\xc3\x82','Â').replace('\xc3\x83','Ã').replace('\xc3\x84','Ä').replace('\xc3\x85','Å').replace('\xc3\x86','Æ').replace('\xc3\x87','Ç').replace('\xc3\x88','È').replace('\xc3\x89','É').replace('\xc3\x8a','Ê').replace('\xc3\x8b','Ë').replace('\xc3\x8c','Ì').replace('\xc3\x8d','Í').replace('\xc3\x8e','Î').replace('\xc3\x8f','Ï').replace('\xc3\x90','Ð').replace('\xc3\x91','Ñ').replace('\xc3\x92','Ò').replace('\xc3\x93','Ó').replace('\xc3\x94','Ô').replace('\xc3\x95','Õ').replace('\xc3\x96','Ö').replace('\xc3\x97','×').replace('\xc3\x98','Ø').replace('\xc3\x99','Ù').replace('\xc3\x9a','Ú').replace('\xc3\x9b','Û').replace('\xc3\x9c','Ü').replace('\xc3\x9d','Ý').replace('\xc3\x9e','Þ').replace('\xc3\x9f','ß').replace('\xc3\xa0','à').replace('\xc3\xa1','á').replace('\xc3\xa2','â').replace('\xc3\xa3','ã').replace('\xc3\xa4','ä').replace('\xc3\xa5','å').replace('\xc3\xa6','æ').replace('\xc3\xa7','ç').replace('\xc3\xa8','è').replace('\xc3\xa9','é').replace('\xc3\xaa','ê').replace('\xc3\xab','ë').replace('\xc3\xac','ì').replace('\xc3\xad','í').replace('\xc3\xae','î').replace('\xc3\xaf','ï').replace('\xc3\xb0','ð').replace('\xc3\xb1','ñ').replace('\xc3\xb2','ò').replace('\xc3\xb3','ó').replace('\xc3\xb4','ô').replace('\xc3\xb5','õ').replace('\xc3\xb6','ö').replace('\xc3\xb7','÷').replace('\xc3\xb8','ø').replace('\xc3\xb9','ù').replace('\xc3\xba','ú').replace('\xc3\xbb','û').replace('\xc3\xbc','u').replace('\xc3\xbd','ý').replace('\xc3\xbe','þ').replace('\xc3\xbf','ÿ').replace('\xc4\x80','Ā').replace('\xc4\x81','ā').replace('\xc4\x82','Ă').replace('\xc4\x83','ă').replace('\xc4\x84','Ą').replace('\xc4\x85','ą').replace('\xc4\x86','Ć').replace('\xc4\x87','ć').replace('\xc4\x88','Ĉ').replace('\xc4\x89','ĉ').replace('\xc4\x8a','Ċ').replace('\xc4\x8b','ċ').replace('\xc4\x8c','Č').replace('\xc4\x8d','č').replace('\xc4\x8e','Ď').replace('\xc4\x8f','ď').replace('\xc4\x90','Đ').replace('\xc4\x91','đ').replace('\xc4\x92','Ē').replace('\xc4\x93','ē').replace('\xc4\x94','Ĕ').replace('\xc4\x95','ĕ').replace('\xc4\x96','Ė').replace('\xc4\x97','ė').replace('\xc4\x98','Ę').replace('\xc4\x99','ę').replace('\xc4\x9a','Ě').replace('\xc4\x9b','ě').replace('\xc4\x9c','Ĝ').replace('\xc4\x9d','ĝ').replace('\xc4\x9e','Ğ').replace('\xc4\x9f','g').replace('\xc4\xa0','Ġ').replace('\xc4\xa1','ġ').replace('\xc4\xa2','Ģ').replace('\xc4\xa3','ģ').replace('\xc4\xa4','Ĥ').replace('\xc4\xa5','ĥ').replace('\xc4\xa6','Ħ').replace('\xc4\xa7','ħ').replace('\xc4\xa8','Ĩ').replace('\xc4\xa9','ĩ').replace('\xc4\xaa','Ī').replace('\xc4\xab','ī').replace('\xc4\xac','Ĭ').replace('\xc4\xad','ĭ').replace('\xc4\xae','Į').replace('\xc4\xaf','į').replace('\xc4\xb0','I').replace('\xc4\xb1','ı').replace('\xc4\xb2','Ĳ').replace('\xc4\xb3','ĳ').replace('\xc4\xb4','Ĵ').replace('\xc4\xb5','ĵ').replace('\xc4\xb6','Ķ').replace('\xc4\xb7','ķ').replace('\xc4\xb8','ĸ').replace('\xc4\xb9','Ĺ').replace('\xc4\xba','ĺ').replace('\xc4\xbb','Ļ').replace('\xc4\xbc','ļ').replace('\xc4\xbd','Ľ').replace('\xc4\xbe','ľ').replace('\xc4\xbf','Ŀ').replace('\xc5\x80','ŀ').replace('\xc5\x81','Ł').replace('\xc5\x82','ł').replace('\xc5\x83','Ń').replace('\xc5\x84','ń').replace('\xc5\x85','Ņ').replace('\xc5\x86','ņ').replace('\xc5\x87','Ň').replace('\xc5\x88','ň').replace('\xc5\x89','ŉ').replace('\xc5\x8a','Ŋ').replace('\xc5\x8b','ŋ').replace('\xc5\x8c','Ō').replace('\xc5\x8d','ō').replace('\xc5\x8e','Ŏ').replace('\xc5\x8f','ŏ').replace('\xc5\x90','Ő').replace('\xc5\x91','ő').replace('\xc5\x92','Œ').replace('\xc5\x93','œ').replace('\xc5\x94','Ŕ').replace('\xc5\x95','ŕ').replace('\xc5\x96','Ŗ').replace('\xc5\x97','ŗ').replace('\xc5\x98','Ř').replace('\xc5\x99','ř').replace('\xc5\x9a','Ś').replace('\xc5\x9b','ś').replace('\xc5\x9c','Ŝ').replace('\xc5\x9d','ŝ').replace('\xc5\x9e','Ş').replace('\xc5\x9f','s').replace('\xc5\xa0','Š').replace('\xc5\xa1','š').replace('\xc5\xa2','Ţ').replace('\xc5\xa3','ţ').replace('\xc5\xa4','Ť').replace('\xc5\xa5','ť').replace('\xc5\xa6','Ŧ').replace('\xc5\xa7','ŧ').replace('\xc5\xa8','Ũ').replace('\xc5\xa9','ũ').replace('\xc5\xaa','Ū').replace('\xc5\xab','ū').replace('\xc5\xac','Ŭ').replace('\xc5\xad','ŭ').replace('\xc5\xae','Ů').replace('\xc5\xaf','ů').replace('\xc5\xb0','Ű').replace('\xc5\xb1','ű').replace('\xc5\xb2','Ų').replace('\xc5\xb3','ų').replace('\xc5\xb4','Ŵ').replace('\xc5\xb5','ŵ').replace('\xc5\xb6','Ŷ').replace('\xc5\xb7','ŷ').replace('\xc5\xb8','Ÿ').replace('\xc5\xb9','Ź').replace('\xc5\xba','ź').replace('\xc5\xbb','Ż').replace('\xc5\xbc','ż').replace('\xc5\xbd','Ž').replace('\xc5\xbe','ž').replace('\xc5\xbf','ſ')
 
        text = (str(text)).replace('&#220;','Ü').replace('&#xA0;',' ').replace('&#xA1;','¡').replace('&#xA2;','¢').replace('&#xA3;','£').replace('&#xA4;','¤').replace('&#xA5;','¥').replace('&#xA6;','¦').replace('&#xA7;','§').replace('&#xA8;','¨').replace('&#xA9;','©').replace('&#xAA;','ª').replace('&#xAB;','«').replace('&#xAC;','¬').replace('&#xAD;','­').replace('&#xAE;','®').replace('&#xAF;','¯').replace('&#xB0;','°').replace('&#xB1;','±').replace('&#xB2;','²').replace('&#xB3;','³').replace('&#xB4;','´').replace('&#xB5;','µ').replace('&#xB6;','¶').replace('&#xB7;','·').replace('&#xB8;','¸').replace('&#xB9;','¹').replace('&#xBA;','º').replace('&#xBB;','»').replace('&#xBC;','¼').replace('&#xBD;','½').replace('&#xBE;','¾').replace('&#xBF;','¿').replace('&#xC0;','À').replace('&#xC1;','Á').replace('&#xC2;','Â').replace('&#xC3;','Ã').replace('&#xC4;','Ä').replace('&#xC5;','Å').replace('&#xC6;','Æ').replace('&#xC7;','Ç').replace('&#xC8;','È').replace('&#xC9;','É').replace('&#xCA;','Ê').replace('&#xCB;','Ë').replace('&#xCC;','Ì').replace('&#xCD;','Í').replace('&#xCE;','Î').replace('&#xCF;','Ï').replace('&#xD0;','Ð').replace('&#xD1;','Ñ').replace('&#xD2;','Ò').replace('&#xD3;','Ó').replace('&#xD4;','Ô').replace('&#xD5;','Õ').replace('&#xD6;','Ö').replace('&#xD7;','×').replace('&#xD8;','Ø').replace('&#xD9;','Ù').replace('&#xDA;','Ú').replace('&#xDB;','Û').replace('&#xDC;','Ü').replace('&#xDD;','Ý').replace('&#xDE;','Þ').replace('&#xDF;','ß').replace('&#xE0;','à').replace('&#xE1;','á').replace('&#xE2;','â').replace('&#xE3;','ã').replace('&#xE4;','ä').replace('&#xE5;','å').replace('&#xE6;','æ').replace('&#xE7;','ç').replace('&#xE8;','è').replace('&#xE9;','é').replace('&#xEA;','ê').replace('&#xEB;','ë').replace('&#xEC;','ì').replace('&#xED;','í').replace('&#xEE;','î').replace('&#xEF;','ï').replace('&#xF0;','ð').replace('&#xF1;','ñ').replace('&#xF2;','ò').replace('&#xF3;','ó').replace('&#xF4;','ô').replace('&#xF5;','õ').replace('&#xF6;','ö').replace('&#xF7;','÷').replace('&#xF8;','ø').replace('&#xF9;','ù').replace('&#xFA;','ú').replace('&#xFB;','û').replace('&#xFC;','ü').replace('&#xFD;','ý').replace('&#xFE;','þ').replace('&#xFF;','ÿ').replace('&#x100;','Ā').replace('&#x101;','ā').replace('&#x102;','Ă').replace('&#x103;','ă').replace('&#x104;','Ą').replace('&#x105;','ą').replace('&#x106;','Ć').replace('&#x107;','ć').replace('&#x108;','Ĉ').replace('&#x109;','ĉ').replace('&#x10A;','Ċ').replace('&#x10B;','ċ').replace('&#x10C;','Č').replace('&#x10D;','č').replace('&#x10E;','Ď').replace('&#x10F;','ď').replace('&#x110;','Đ').replace('&#x111;','đ').replace('&#x112;','Ē').replace('&#x113;','ē').replace('&#x114;','Ĕ').replace('&#x115;','ĕ').replace('&#x116;','Ė').replace('&#x117;','ė').replace('&#x118;','Ę').replace('&#x119;','ę').replace('&#x11A;','Ě').replace('&#x11B;','ě').replace('&#x11C;','Ĝ').replace('&#x11D;','ĝ').replace('&#x11E;','Ğ').replace('&#x11F;','ğ').replace('&#x120;','Ġ').replace('&#x121;','ġ').replace('&#x122;','Ģ').replace('&#x123;','ģ').replace('&#x124;','Ĥ').replace('&#x125;','ĥ').replace('&#x126;','Ħ').replace('&#x127;','ħ').replace('&#x128;','Ĩ').replace('&#x129;','ĩ').replace('&#x12A;','Ī').replace('&#x12B;','ī').replace('&#x12C;','Ĭ').replace('&#x12D;','ĭ').replace('&#x12E;','Į').replace('&#x12F;','į').replace('&#x130;','İ').replace('&#x131;','ı').replace('&#x132;','Ĳ').replace('&#x133;','ĳ').replace('&#x134;','Ĵ').replace('&#x135;','ĵ').replace('&#x136;','Ķ').replace('&#x137;','ķ').replace('&#x138;','ĸ').replace('&#x139;','Ĺ').replace('&#x13A;','ĺ').replace('&#x13B;','Ļ').replace('&#x13C;','ļ').replace('&#x13D;','Ľ').replace('&#x13E;','ľ').replace('&#x13F;','Ŀ').replace('&#x140;','ŀ').replace('&#x141;','Ł').replace('&#x142;','ł').replace('&#x143;','Ń').replace('&#x144;','ń').replace('&#x145;','Ņ').replace('&#x146;','ņ').replace('&#x147;','Ň').replace('&#x148;','ň').replace('&#x149;','ŉ').replace('&#x14A;','Ŋ').replace('&#x14B;','ŋ').replace('&#x14C;','Ō').replace('&#x14D;','ō').replace('&#x14E;','Ŏ').replace('&#x14F;','ŏ').replace('&#x150;','Ő').replace('&#x151;','ő').replace('&#x152;','Œ').replace('&#x153;','œ').replace('&#x154;','Ŕ').replace('&#x155;','ŕ').replace('&#x156;','Ŗ').replace('&#x157;','ŗ').replace('&#x158;','Ř').replace('&#x159;','ř').replace('&#x15A;','Ś').replace('&#x15B;','ś').replace('&#x15C;','Ŝ').replace('&#x15D;','ŝ').replace('&#x15E;','Ş').replace('&#x15F;','ş').replace('&#x160;','Š').replace('&#x161;','š').replace('&#x162;','Ţ').replace('&#x163;','ţ').replace('&#x164;','Ť').replace('&#x165;','ť').replace('&#x166;','Ŧ').replace('&#x167;','ŧ').replace('&#x168;','Ũ').replace('&#x169;','ũ').replace('&#x16A;','Ū').replace('&#x16B;','ū').replace('&#x16C;','Ŭ').replace('&#x16D;','ŭ').replace('&#x16E;','Ů').replace('&#x16F;','ů').replace('&#x170;','Ű').replace('&#x171;','ű').replace('&#x172;','Ų').replace('&#x173;','ų').replace('&#x174;','Ŵ').replace('&#x175;','ŵ').replace('&#x176;','Ŷ').replace('&#x177;','ŷ').replace('&#x178;','Ÿ').replace('&#x179;','Ź').replace('&#x17A;','ź').replace('&#x17B;','Ż').replace('&#x17C;','ż').replace('&#x17D;','Ž').replace('&#x17E;','ž').replace('&#x17F;','ſ')

        text = (str(text)).replace('�','C').replace('\xf6',"ö").replace('\xf0',"ğ").replace('\xfc',"ü").replace('\xfd',"ı").replace('\xe7',"ç").replace('\xfe',"ş").replace('\xd6',"Ö").replace('\xc7',"Ç").replace('\xdd',"İ").replace('\xde',"Ş").replace('\xdc',"Ü").replace('&#304;',"İ").replace('&#305;',"ı").replace('&#214;',"Ö").replace('&#246;',"ö").replace('&#220;',"Ü").replace('&#252;',"ü").replace('&#199;',"Ç").replace('&#231;',"ç").replace('&#286;',"Ğ").replace('&#287;',"ğ").replace('&#350;',"Ş").replace('&#351;',"ş").replace('\xe2',"â").replace('\xe2',"â")
        return text
     
from resources.lib import jsunprotect
def ABCkodla(sMovieTitle):
    
    sMovieTitle = sMovieTitle.decode("unicode_escape").encode("utf-8")#vire accent et '\'
     #on repasse en utf-8
 
    return sMovieTitle

UA = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36'
def streamango(url):
    oGui = cGui()
  
    if not 'http' in url:
       url = 'http:'+ url
    
    data=requests.get(url,headers={'Host':'streamango.com','User-Agent':UA,'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;','Connection':'keep-alive'}).text
            
    stream_url = re.findall('type:"video/mp4",src:"(.*?)",height:(.*?),',data, re.S)
    for sUrl,sTitle in stream_url:
                                              
         
        sUrl = 'https:'+ sUrl 
        sTitle = alfabekodla(sTitle)         
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl',str(sUrl))
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER , 'showBoxxx', sTitle, 'tv.png', oOutputParameterHandler)
    
  
    oGui.setEndOfDirectory()  
        
def streamcloud(url):
		net = Net()
                if not 'http' in url:
                   url = 'http:'+ url
                data = net.http_GET(url).content
		id = re.findall('<input type="hidden" name="id".*?value="(.*?)">', data)
		fname = re.findall('<input type="hidden" name="fname".*?alue="(.*?)">', data)
		hash = re.findall('<input type="hidden" name="hash" value="(.*?)">', data)
		if id and fname and hash:
		    url = "http://streamcloud.eu/%s" % id[0]			
		    info = {'op': 'download2', 'usr_login': '', 'id': id[0], 'fname': fname[0], 'referer': '', 'hash': hash[0], 'imhuman':'Weiter+zum+Video'}
                
                    name = "streamcloud.eu" 
		    data = net.http_POST(url, info).content
		    stream_url = re.findall('file: "(.*?)"', data)
                    url =stream_url[0]
                    name = 'streamcloud'
                    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
    
def fflashx(url):
    headers = {'Host': 'www.flashx.tv',
                   'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                   'Accept-Language': 'en-US,en;q=0.5',
                   'Accept-Encoding': 'gzip, deflate, br', 'Connection': 'keep-alive', 'Upgrade-Insecure-Requests': '1',
                   'Cookie': ''}       
    oGui = cGui()
    data = httptools.downloadpage(url, headers=headers, replace_headers=True).data
    flashx_id = scrapertools.find_single_match(data, 'name="id" value="([^"]+)"')
    fname = scrapertools.find_single_match(data, 'name="fname" value="([^"]+)"')
    hash_f = scrapertools.find_single_match(data, 'name="hash" value="([^"]+)"')
    post = 'op=download1&usr_login=&id=%s&fname=%s&referer=&hash=%s&imhuman=Proceed+to+video' % (
    flashx_id, urllib.quote(fname), hash_f)                     
    wait_time = scrapertools.find_single_match(data, "<span id='xxc2'>(\d+)")

    file_id = scrapertools.find_single_match(data, "'file_id', '([^']+)'")
    coding_url = 'https://files.fx.fastcontentdelivery.com/jquery2.js?fx=%s' % base64.encodestring(file_id)
    headers['Host'] = "files.fx.fastcontentdelivery.com"
    headers['Referer'] = "https://www.flashx.tv/"
    headers['Accept'] = "*/*"
    coding = httptools.downloadpage(coding_url, headers=headers, replace_headers=True).data

    coding_url = 'https://www.flashx.tv/counter.cgi?fx=%s' % base64.encodestring(file_id)
    headers['Host'] = "www.flashx.tv"
    coding = httptools.downloadpage(coding_url, headers=headers, replace_headers=True).data

    coding_url = 'https://www.flashx.tv/flashx.php?fxfx=3'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    coding = httptools.downloadpage(coding_url, headers=headers, replace_headers=True).data

    try:
       time.sleep(int(wait_time) + 1)
    except:
       time.sleep(6)

    headers.pop('X-Requested-With')
    headers['Content-Type'] = 'application/x-www-form-urlencoded'
    urlk = httptools.downloadpage('https://www.flashx.tv/dl?playthis',post, headers, replace_headers=True).data
    stream_url = re.findall("src: '(.*?)',type: 'video/mp4',label: '(.*?)'",urlk , re.S)
    for sUrl,sTitle in stream_url:
                                              
         
         
        sTitle = alfabekodla(sTitle)         
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl',str(sUrl))
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER , 'showBoxxx', sTitle, 'tv.png', oOutputParameterHandler)
    
  
    oGui.setEndOfDirectory()                      
           
    





def thevideome(url):
    oGui = cGui()	
    data = net.http_GET(url).content
    stream_url = re.findall('"file":"(.*?)","label":"(.*?)"', data,re.DOTALL)
    for sUrl,sTitle in stream_url:
        key = re.findall("var lets_play_a_game='(.*?)'",data,re.DOTALL)
        ke = re.findall("'rc=[^<>]+?\/(.+?)'\.concat",data,re.DOTALL)
        url2 = 'https://thevideo.me/'+ ke[0]+'/' + key[0] 
       
       
                
        data_pack= net.http_GET(url2).content
        data_pack = data_pack.replace('|httpfallback','').replace('|in',"").replace('|indexOf',"").replace('|jwConfig',"").replace('|return',"").replace('|sources',"").replace('|ua',"").replace('|vt',"").replace('|file',"").replace('|false',"").replace('|direct',"").replace('|var',"").replace('|for',"").replace('|if',"").replace('|playlist',"").replace('|length',"").replace('|function',"").replace('|',"")
        keyi = re.findall(",30,'(.+?)'.split",data_pack,re.DOTALL)
        sUrl=sUrl+ '?direct=false&ua=1&vt='+keyi[0]
        
        sTitle = alfabekodla(sTitle)         
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl',str(sUrl))
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER , 'showBoxxx', sTitle, 'tv.png', oOutputParameterHandler)
    
  
    oGui.setEndOfDirectory()  

        

       

def raptu(url):                    
    oGui = cGui()	
    data = net.http_GET(url).content
    data=data.replace('\/',"/").replace('"file":"https://www.raptu.com',"")
      
    stream_url = re.findall('"file":"(.*?)","label":"(.*?)"',data, re.S)
    for sUrl,sTitle in stream_url:
                                              
         
         
        sTitle = alfabekodla(sTitle)         
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl',str(sUrl))
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER , 'showBoxxx', sTitle, 'tv.png', oOutputParameterHandler)
    
  
    oGui.setEndOfDirectory()  
   
def name_prepare(videoTitle):
        print 'DUZELTME ONCESI:',videoTitle
        videoTitle=videoTitle.replace('�zle',"").replace('T�rk�e',"").replace('Turkce',"").replace('Dublaj',"|TR|").replace('Altyaz�l�'," [ ALTYAZILI ] ").replace('izle',"").replace('Full',"").replace('720p',"").replace('HD',"")
        return videoTitle   
        
def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xFD',"i").replace('&#39;&#39;',"\"").replace('&#39;',"\'").replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        link=link.replace('\xc5\x9f',"s").replace('&#038;',"&").replace('&#8217;',"'").replace('\xc3\xbc',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"�").replace('&#8211;',"-").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc4\x9f',"g").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
        response.close()
        return link

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok


def addDir(name,url,thumbnail,mode,filepath):
        if thumbnail != "":
                thumbnail = os.path.join(IMAGES_PATH, thumbnail+".jpg")
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&thumbnail="+urllib.quote_plus(thumbnail)+"&filepath="+urllib.quote_plus(filepath)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def videoraj(url):
        fileName ="cozucu"
        data = net.http_GET(url).content
        TIK='|User-Agent=User-Agent:Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Mobile Safari/537.36'

        url = re.findall('key: "(.*?)".*?file:"(.*?)"', data, re.S)                                      
        for filekey, media_id in url:

            player_url = 'http://www.videoraj.to/api/player.api.php?pass=&numOfErrors=0&cid=1&cid3=&key=%s&user=&cid2=&file=%s' % (filekey, media_id)

            html = net.http_GET(player_url).content
            html=html.replace('%3D',"=").replace('%26',"&").replace('%3F',"?").replace('%3A',":").replace('%2F',"/").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc4\x9f',"g").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
	
            url= re.findall('url=(.+?)&', html)[0]+TIK  
            
            
                                                             
	    name = 'videoraj'
            addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')


        
def fileztv(url):
        html2  = net.http_GET(url).content
        url1= re.search(r'<div class="largeDownloadButtons">.*?<a href="(.*?)">', html2, re.S)         
        url1= url1.group(1)
       
        html  = net.http_GET(url1).content
        
        r = re.findall('file: "(.*?)"', html)
        url= url[0]
           
        name = 'fileztv'
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')

def vivosx(url):

            html  = requests.get(url).content
            url= re.search(r'Core\.InitializeStream \(\'(.*?)\'\)', html)        
            
            b = base64.b64decode(url.group(1))
            url = json.loads(b)
            if len(url) == 0: raise ResolverError('video not found')
            TIK='|User-Agent=Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'

            url= url[0]+TIK
           
            name = 'vivosx'
            addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
        
def vidzitv(url):
           
            html  = requests.get(url).content
            url= re.findall('file: "http://.*?/master.m3u8".,.file: "(.*?)"', html)        
           
            TIK='|User-Agent=Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'

            url= url[0]+TIK
           
            name = 'vidzi.tv'
            addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')


def magix_player(name,url):
    import urlresolver
    UrlResolverPlayer = url
    playList.clear()
    media = urlresolver.HostedMediaFile(UrlResolverPlayer)
    source = media
    if source:
            url = source.resolve()
            
            playlist_yap(playList,name,url)
            xbmcPlayer.play(playList)

                  
def playlist_yap(playList,name,url):
        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="")
        listitem.setInfo('video', {'name': name } )
        playList.add(url,listitem=listitem)
        return playList
    #---------------------------------#
USER_AGENT 	= 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36'
ACCEPT 		= 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'

def ok_ru(url):
        fileName ="cozucu"


        sources = []

        if(re.search(r'ok.ru', url)):
            
               # try:
            id = re.search('\d+', url).group(0)
            jsonUrl = 'http://ok.ru/dk?cmd=videoPlayerMetadata&mid=' + id
            jsonSource = json.loads(http_req(jsonUrl))
            
            for source in jsonSource['videos']:
                    name = '%s %s' % ('', source['name'])
                    link = '%s|User-Agent=%s&Accept=%s&Referer=%s' % (source['url'], USER_AGENT, ACCEPT, urllib.quote_plus(url))
                    #item = {'name': name, 'url': link}
                    #sources.append(item)
                    url = link
                    print url
                    araclar.addDir(fileName,'[COLOR beige][B][COLOR blue]>>[/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,"")
               # except: pass
        #return sources

def http_req(url, getCookie=False):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	req.add_header('Accept', ACCEPT)
	req.add_header('Cache-Control', 'no-transform')
	response = urllib2.urlopen(req)
	source = response.read()
	response.close()
	if getCookie:
		cookie = response.headers.get('Set-Cookie')
		return {'source': source, 'cookie': cookie}
	return source
def PlayPlay(url):
    name = 'Direct line'
    url=alfabekodla(url)    
    listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
    listitem.setInfo(type="Video", infoLabels={ "Title": name })
    xbmc.Player().play( url , listitem)
def PlayerPlayer(name,url):

    url=alfabekodla(url)    
    listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
    listitem.setInfo(type="Video", infoLabels={ "Title": name })
    xbmc.Player().play( url , listitem)
def MailRu_Player(url):
    req = urllib2.Request(url)

    resp = urllib2.urlopen(req)
    html = resp.read()
    cookie_string = resp.headers.getheader('Set-Cookie').split(';')[0]

    print resp.headers.getheader('Set-Cookie')
    headers = {
        'Cookie': cookie_string
    }

    metadata_url_start = html.find('metadataUrl') + len('metadataUrl":"')
    metadata_url_end = html.find('"', metadata_url_start)
    metadata_url = html[metadata_url_start:metadata_url_end]

    metadata_response =  urllib2.urlopen(metadata_url)
    metadata = json.loads(metadata_response.read()) 

    #---------------------------------#
    xbmc_cookies = '|Cookie=' + urllib.quote(cookie_string)
    streams = [(v['key'], v['url'] + xbmc_cookies) for v in metadata['videos']]
    for name,url in streams:
            addLink('[COLOR lightblue][B]M_R >>  [/B][/COLOR]'+name,url,'')
    #---------------------------------#

def magictr():
       oGui = cGui() 
       sMovieTitle='http://www.youtube.com/embed/6VAquSxygQE'
       HosterUrl='http://www.youtube.com/embed/6VAquSxygQE'
        
       oHoster = cHosterGui().checkHoster(sHosterUrl)

       if (oHoster != False):
           sDisplayTitle = cUtil().DecoTitle(sMovieTitle)
           oHoster.setDisplayName(sDisplayTitle)
           oHoster.setFileName(sMovieTitle)
           cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

       

       oGui.setEndOfDirectory()

def alfabekodla(text):
       
        text = (str(text)).replace("0x99","?").replace('\xc2\xa0',' ').replace('\xc3\xa7','c').replace('\xe2\x80\x93',' - ').replace('\xc4\xb1','i').replace('\xc3\xb6','o').replace('xc3\xbc','u').replace('xc5\x9f','s').replace('\xc5\x9e','S').replace('xc4\x9f','g').replace('\xc3\x87','C').replace('\xc3\x96','O').replace('\xc3\x9c','U').replace('\xc2\xa1','¡').replace('\xc2\xa2','¢').replace('&#039;','`').replace('\xc2\xa3','£').replace('\xc2\xa4','¤').replace('\xc2\xa5','¥').replace('\xc2\xa6','¦').replace('\xc2\xa7','§').replace('\xc2\xa8','¨').replace('\xc2\xa9','©').replace('\xc2\xaa','ª').replace('\xc2\xab','«').replace('\xc2\xac','¬').replace('\xc2\xad','­').replace('\xc2\xae','®').replace('\xc2\xaf','¯').replace('\xc2\xb0','°').replace('\xc2\xb1','±').replace('\xc2\xb2','²').replace('\xc2\xb3','³').replace('\xc2\xb4','´').replace('\xc2\xb5','µ').replace('\xc2\xb6','¶').replace('\xc2\xb7','·').replace('\xc2\xb8','¸').replace('\xc2\xb9','¹').replace('\xc2\xba','º').replace('\xc2\xbb','»').replace('\xc2\xbc','¼').replace('\xc2\xbd','½').replace('\xc2\xbe','¾').replace('\xc2\xbf','¿').replace('\xc3\x80','À').replace('\xc3\x81','Á').replace('\xc3\x82','Â').replace('\xc3\x83','Ã').replace('\xc3\x84','Ä').replace('\xc3\x85','Å').replace('\xc3\x86','Æ').replace('\xc3\x87','Ç').replace('\xc3\x88','È').replace('\xc3\x89','É').replace('\xc3\x8a','Ê').replace('\xc3\x8b','Ë').replace('\xc3\x8c','Ì').replace('\xc3\x8d','Í').replace('\xc3\x8e','Î').replace('\xc3\x8f','Ï').replace('\xc3\x90','Ð').replace('\xc3\x91','Ñ').replace('\xc3\x92','Ò').replace('\xc3\x93','Ó').replace('\xc3\x94','Ô').replace('\xc3\x95','Õ').replace('\xc3\x96','Ö').replace('\xc3\x97','×').replace('\xc3\x98','Ø').replace('\xc3\x99','Ù').replace('\xc3\x9a','Ú').replace('\xc3\x9b','Û').replace('\xc3\x9c','Ü').replace('\xc3\x9d','Ý').replace('\xc3\x9e','Þ').replace('\xc3\x9f','ß').replace('\xc3\xa0','à').replace('\xc3\xa1','á').replace('\xc3\xa2','â').replace('\xc3\xa3','ã').replace('\xc3\xa4','ä').replace('\xc3\xa5','å').replace('\xc3\xa6','æ').replace('\xc3\xa7','ç').replace('\xc3\xa8','è').replace('\xc3\xa9','é').replace('\xc3\xaa','ê').replace('\xc3\xab','ë').replace('\xc3\xac','ì').replace('\xc3\xad','í').replace('\xc3\xae','î').replace('\xc3\xaf','ï').replace('\xc3\xb0','ð').replace('\xc3\xb1','ñ').replace('\xc3\xb2','ò').replace('\xc3\xb3','ó').replace('\xc3\xb4','ô').replace('\xc3\xb5','õ').replace('\xc3\xb6','ö').replace('\xc3\xb7','÷').replace('\xc3\xb8','ø').replace('\xc3\xb9','ù').replace('\xc3\xba','ú').replace('\xc3\xbb','û').replace('\xc3\xbc','u').replace('\xc3\xbd','ý').replace('\xc3\xbe','þ').replace('\xc3\xbf','ÿ').replace('\xc4\x80','Ā').replace('\xc4\x81','ā').replace('\xc4\x82','Ă').replace('\xc4\x83','ă').replace('\xc4\x84','Ą').replace('\xc4\x85','ą').replace('\xc4\x86','Ć').replace('\xc4\x87','ć').replace('\xc4\x88','Ĉ').replace('\xc4\x89','ĉ').replace('\xc4\x8a','Ċ').replace('\xc4\x8b','ċ').replace('\xc4\x8c','Č').replace('\xc4\x8d','č').replace('\xc4\x8e','Ď').replace('\xc4\x8f','ď').replace('\xc4\x90','Đ').replace('\xc4\x91','đ').replace('\xc4\x92','Ē').replace('\xc4\x93','ē').replace('\xc4\x94','Ĕ').replace('\xc4\x95','ĕ').replace('\xc4\x96','Ė').replace('\xc4\x97','ė').replace('\xc4\x98','Ę').replace('\xc4\x99','ę').replace('\xc4\x9a','Ě').replace('\xc4\x9b','ě').replace('\xc4\x9c','Ĝ').replace('\xc4\x9d','ĝ').replace('\xc4\x9e','Ğ').replace('\xc4\x9f','g').replace('\xc4\xa0','Ġ').replace('\xc4\xa1','ġ').replace('\xc4\xa2','Ģ').replace('\xc4\xa3','ģ').replace('\xc4\xa4','Ĥ').replace('\xc4\xa5','ĥ').replace('\xc4\xa6','Ħ').replace('\xc4\xa7','ħ').replace('\xc4\xa8','Ĩ').replace('\xc4\xa9','ĩ').replace('\xc4\xaa','Ī').replace('\xc4\xab','ī').replace('\xc4\xac','Ĭ').replace('\xc4\xad','ĭ').replace('\xc4\xae','Į').replace('\xc4\xaf','į').replace('\xc4\xb0','I').replace('\xc4\xb1','ı').replace('\xc4\xb2','Ĳ').replace('\xc4\xb3','ĳ').replace('\xc4\xb4','Ĵ').replace('\xc4\xb5','ĵ').replace('\xc4\xb6','Ķ').replace('\xc4\xb7','ķ').replace('\xc4\xb8','ĸ').replace('\xc4\xb9','Ĺ').replace('\xc4\xba','ĺ').replace('\xc4\xbb','Ļ').replace('\xc4\xbc','ļ').replace('\xc4\xbd','Ľ').replace('\xc4\xbe','ľ').replace('\xc4\xbf','Ŀ').replace('\xc5\x80','ŀ').replace('\xc5\x81','Ł').replace('\xc5\x82','ł').replace('\xc5\x83','Ń').replace('\xc5\x84','ń').replace('\xc5\x85','Ņ').replace('\xc5\x86','ņ').replace('\xc5\x87','Ň').replace('\xc5\x88','ň').replace('\xc5\x89','ŉ').replace('\xc5\x8a','Ŋ').replace('\xc5\x8b','ŋ').replace('\xc5\x8c','Ō').replace('\xc5\x8d','ō').replace('\xc5\x8e','Ŏ').replace('\xc5\x8f','ŏ').replace('\xc5\x90','Ő').replace('\xc5\x91','ő').replace('\xc5\x92','Œ').replace('\xc5\x93','œ').replace('\xc5\x94','Ŕ').replace('\xc5\x95','ŕ').replace('\xc5\x96','Ŗ').replace('\xc5\x97','ŗ').replace('\xc5\x98','Ř').replace('\xc5\x99','ř').replace('\xc5\x9a','Ś').replace('\xc5\x9b','ś').replace('\xc5\x9c','Ŝ').replace('\xc5\x9d','ŝ').replace('\xc5\x9e','Ş').replace('\xc5\x9f','s').replace('\xc5\xa0','Š').replace('\xc5\xa1','š').replace('\xc5\xa2','Ţ').replace('\xc5\xa3','ţ').replace('\xc5\xa4','Ť').replace('\xc5\xa5','ť').replace('\xc5\xa6','Ŧ').replace('\xc5\xa7','ŧ').replace('\xc5\xa8','Ũ').replace('\xc5\xa9','ũ').replace('\xc5\xaa','Ū').replace('\xc5\xab','ū').replace('\xc5\xac','Ŭ').replace('\xc5\xad','ŭ').replace('\xc5\xae','Ů').replace('\xc5\xaf','ů').replace('\xc5\xb0','Ű').replace('\xc5\xb1','ű').replace('\xc5\xb2','Ų').replace('\xc5\xb3','ų').replace('\xc5\xb4','Ŵ').replace('\xc5\xb5','ŵ').replace('\xc5\xb6','Ŷ').replace('\xc5\xb7','ŷ').replace('\xc5\xb8','Ÿ').replace('\xc5\xb9','Ź').replace('\xc5\xba','ź').replace('\xc5\xbb','Ż').replace('\xc5\xbc','ż').replace('\xc5\xbd','Ž').replace('\xc5\xbe','ž').replace('\xc5\xbf','ſ')
        text = (str(text)).replace('&#220;','Ü').replace('&#xA0;',' ').replace('&#xA1;','¡').replace('&#xA2;','¢').replace('&#xA3;','£').replace('&#xA4;','¤').replace('&#xA5;','¥').replace('&#xA6;','¦').replace('&#xA7;','§').replace('&#xA8;','¨').replace('&#xA9;','©').replace('&#xAA;','ª').replace('&#xAB;','«').replace('&#xAC;','¬').replace('&#xAD;','­').replace('&#xAE;','®').replace('&#xAF;','¯').replace('&#xB0;','°').replace('&#xB1;','±').replace('&#xB2;','²').replace('&#xB3;','³').replace('&#xB4;','´').replace('&#xB5;','µ').replace('&#xB6;','¶').replace('&#xB7;','·').replace('&#xB8;','¸').replace('&#xB9;','¹').replace('&#xBA;','º').replace('&#xBB;','»').replace('&#xBC;','¼').replace('&#xBD;','½').replace('&#xBE;','¾').replace('&#xBF;','¿').replace('&#xC0;','À').replace('&#xC1;','Á').replace('&#xC2;','Â').replace('&#xC3;','Ã').replace('&#xC4;','Ä').replace('&#xC5;','Å').replace('&#xC6;','Æ').replace('&#xC7;','Ç').replace('&#xC8;','È').replace('&#xC9;','É').replace('&#xCA;','Ê').replace('&#xCB;','Ë').replace('&#xCC;','Ì').replace('&#xCD;','Í').replace('&#xCE;','Î').replace('&#xCF;','Ï').replace('&#xD0;','Ð').replace('&#xD1;','Ñ').replace('&#xD2;','Ò').replace('&#xD3;','Ó').replace('&#xD4;','Ô').replace('&#xD5;','Õ').replace('&#xD6;','Ö').replace('&#xD7;','×').replace('&#xD8;','Ø').replace('&#xD9;','Ù').replace('&#xDA;','Ú').replace('&#xDB;','Û').replace('&#xDC;','Ü').replace('&#xDD;','Ý').replace('&#xDE;','Þ').replace('&#xDF;','ß').replace('&#xE0;','à').replace('&#xE1;','á').replace('&#xE2;','â').replace('&#xE3;','ã').replace('&#xE4;','ä').replace('&#xE5;','å').replace('&#xE6;','æ').replace('&#xE7;','ç').replace('&#xE8;','è').replace('&#xE9;','é').replace('&#xEA;','ê').replace('&#xEB;','ë').replace('&#xEC;','ì').replace('&#xED;','í').replace('&#xEE;','î').replace('&#xEF;','ï').replace('&#xF0;','ð').replace('&#xF1;','ñ').replace('&#xF2;','ò').replace('&#xF3;','ó').replace('&#xF4;','ô').replace('&#xF5;','õ').replace('&#xF6;','ö').replace('&#xF7;','÷').replace('&#xF8;','ø').replace('&#xF9;','ù').replace('&#xFA;','ú').replace('&#xFB;','û').replace('&#xFC;','ü').replace('&#xFD;','ý').replace('&#xFE;','þ').replace('&#xFF;','ÿ').replace('&#x100;','Ā').replace('&#x101;','ā').replace('&#x102;','Ă').replace('&#x103;','ă').replace('&#x104;','Ą').replace('&#x105;','ą').replace('&#x106;','Ć').replace('&#x107;','ć').replace('&#x108;','Ĉ').replace('&#x109;','ĉ').replace('&#x10A;','Ċ').replace('&#x10B;','ċ').replace('&#x10C;','Č').replace('&#x10D;','č').replace('&#x10E;','Ď').replace('&#x10F;','ď').replace('&#x110;','Đ').replace('&#x111;','đ').replace('&#x112;','Ē').replace('&#x113;','ē').replace('&#x114;','Ĕ').replace('&#x115;','ĕ').replace('&#x116;','Ė').replace('&#x117;','ė').replace('&#x118;','Ę').replace('&#x119;','ę').replace('&#x11A;','Ě').replace('&#x11B;','ě').replace('&#x11C;','Ĝ').replace('&#x11D;','ĝ').replace('&#x11E;','Ğ').replace('&#x11F;','ğ').replace('&#x120;','Ġ').replace('&#x121;','ġ').replace('&#x122;','Ģ').replace('&#x123;','ģ').replace('&#x124;','Ĥ').replace('&#x125;','ĥ').replace('&#x126;','Ħ').replace('&#x127;','ħ').replace('&#x128;','Ĩ').replace('&#x129;','ĩ').replace('&#x12A;','Ī').replace('&#x12B;','ī').replace('&#x12C;','Ĭ').replace('&#x12D;','ĭ').replace('&#x12E;','Į').replace('&#x12F;','į').replace('&#x130;','İ').replace('&#x131;','ı').replace('&#x132;','Ĳ').replace('&#x133;','ĳ').replace('&#x134;','Ĵ').replace('&#x135;','ĵ').replace('&#x136;','Ķ').replace('&#x137;','ķ').replace('&#x138;','ĸ').replace('&#x139;','Ĺ').replace('&#x13A;','ĺ').replace('&#x13B;','Ļ').replace('&#x13C;','ļ').replace('&#x13D;','Ľ').replace('&#x13E;','ľ').replace('&#x13F;','Ŀ').replace('&#x140;','ŀ').replace('&#x141;','Ł').replace('&#x142;','ł').replace('&#x143;','Ń').replace('&#x144;','ń').replace('&#x145;','Ņ').replace('&#x146;','ņ').replace('&#x147;','Ň').replace('&#x148;','ň').replace('&#x149;','ŉ').replace('&#x14A;','Ŋ').replace('&#x14B;','ŋ').replace('&#x14C;','Ō').replace('&#x14D;','ō').replace('&#x14E;','Ŏ').replace('&#x14F;','ŏ').replace('&#x150;','Ő').replace('&#x151;','ő').replace('&#x152;','Œ').replace('&#x153;','œ').replace('&#x154;','Ŕ').replace('&#x155;','ŕ').replace('&#x156;','Ŗ').replace('&#x157;','ŗ').replace('&#x158;','Ř').replace('&#x159;','ř').replace('&#x15A;','Ś').replace('&#x15B;','ś').replace('&#x15C;','Ŝ').replace('&#x15D;','ŝ').replace('&#x15E;','Ş').replace('&#x15F;','ş').replace('&#x160;','Š').replace('&#x161;','š').replace('&#x162;','Ţ').replace('&#x163;','ţ').replace('&#x164;','Ť').replace('&#x165;','ť').replace('&#x166;','Ŧ').replace('&#x167;','ŧ').replace('&#x168;','Ũ').replace('&#x169;','ũ').replace('&#x16A;','Ū').replace('&#x16B;','ū').replace('&#x16C;','Ŭ').replace('&#x16D;','ŭ').replace('&#x16E;','Ů').replace('&#x16F;','ů').replace('&#x170;','Ű').replace('&#x171;','ű').replace('&#x172;','Ų').replace('&#x173;','ų').replace('&#x174;','Ŵ').replace('&#x175;','ŵ').replace('&#x176;','Ŷ').replace('&#x177;','ŷ').replace('&#x178;','Ÿ').replace('&#x179;','Ź').replace('&#x17A;','ź').replace('&#x17B;','Ż').replace('&#x17C;','ż').replace('&#x17D;','Ž').replace('&#x17E;','ž').replace('&#x17F;','ſ')
        text = (str(text)).replace('�','C').replace('\xf6',"ö").replace('\xf0',"ğ").replace('\xfc',"ü").replace('\xfd',"ı").replace('\xe7',"ç").replace('\xfe',"ş").replace('\xd6',"Ö").replace('\xc7',"Ç").replace('\xdd',"İ").replace('\xde',"Ş").replace('\xdc',"Ü").replace('&#304;',"İ").replace('&#305;',"ı").replace('&#214;',"Ö").replace('&#246;',"ö").replace('&#220;',"Ü").replace('&#252;',"ü").replace('&#199;',"Ç").replace('&#231;',"ç").replace('&#286;',"Ğ").replace('&#287;',"ğ").replace('&#350;',"Ş").replace('&#351;',"ş").replace('\xe2',"â").replace('\xe2',"â")

        text = (str(text)).replace('\\x','')
        text = (str(text)).replace('&auml;','ä')
	text = (str(text)).replace('\u00e4','ä')
	text = (str(text)).replace('\ufeff','ä')
        text = (str(text)).replace('&#228;','ä')
	text = (str(text)).replace('&Auml;','Ä')
	text = (str(text)).replace('\u00c4','Ä')
	text = (str(text)).replace('&#196;','Ä')
	text = (str(text)).replace('&ouml;','ö')
	text = (str(text)).replace('\u00f6','ö')
	text = (str(text)).replace('&#246;','ö')
	text = (str(text)).replace('&ouml;','Ö')
	text = (str(text)).replace('&Ouml;','Ö')
	text = (str(text)).replace('\u00d6','Ö')
	text = (str(text)).replace('&#214;','Ö')
	text = (str(text)).replace('&uuml;','ü')
	text = (str(text)).replace('\u00fc','ü')
	text = (str(text)).replace('&#252;','ü')
	text = (str(text)).replace('&Uuml;','Ü')
	text = (str(text)).replace('\u00dc','Ü')
	text = (str(text)).replace('&#220;','Ü')
        text = (str(text)).replace('tv_','player')
	text = (str(text)).replace('&szlig;','ß')
	text = (str(text)).replace('\u00df','ß')
	text = (str(text)).replace('&#223;','ß')
	text = (str(text)).replace('&amp;','&')
	text = (str(text)).replace('&quot;','\"')
	text = (str(text)).replace('&gt;','>')
	text = (str(text)).replace('&apos;',"'")
	text = (str(text)).replace('&acute;','\'')
	text = (str(text)).replace('&ndash;','-')
	text = (str(text)).replace('&bdquo;','"')
	text = (str(text)).replace('&rdquo;','"')
	text = (str(text)).replace('&ldquo;','"')
	text = (str(text)).replace('&lsquo;','\'')
	text = (str(text)).replace('&rsquo;','\'')
	text = (str(text)).replace('&#034;','\'')
	text = (str(text)).replace('&#038;','&')
	text = (str(text)).replace('&#039;','\'')
	text = (str(text)).replace('&#39;','\'')
	text = (str(text)).replace('&#160;',' ')
	text = (str(text)).replace('\u00a0',' ')
	text = (str(text)).replace('\u00b4','\'')
	text = (str(text)).replace('&#174;','')
	text = (str(text)).replace('&#225;','a')
	text = (str(text)).replace('&#233;','e')
	text = (str(text)).replace('&#243;','o')
	text = (str(text)).replace('&#8211;',"-")
	text = (str(text)).replace('\u2013',"-")
	text = (str(text)).replace('&#8216;',"'")
	text = (str(text)).replace('&#8217;',"'")
	text = (str(text)).replace('&#8220;',"'")
	text = (str(text)).replace('&#8221;','"')
	text = (str(text)).replace('&#8222;',',')
	text = (str(text)).replace('\u201e','\"')
	text = (str(text)).replace('\u201c','\"')
	text = (str(text)).replace('\u201d','\'')
	text = (str(text)).replace('\u2019s','\'')
	text = (str(text)).replace('\u00e0','à')
	text = (str(text)).replace('\u00e7','ç')
	text = (str(text)).replace('\u00e9','é')
	text = (str(text)).replace('&#xC4;','Ä')
	text = (str(text)).replace('&#xD6;','Ö')
	text = (str(text)).replace('&#xDC;','Ü')
	text = (str(text)).replace('&#xE4;','ä')
	text = (str(text)).replace('&#xF6;','ö')
	text = (str(text)).replace('&#xFC;','ü')
	text = (str(text)).replace('&#xDF;','ß')
	text = (str(text)).replace('&#xE9;','é')
	text = (str(text)).replace('&#xB7;','·')
	text = (str(text)).replace("&#x27;","'")
	text = (str(text)).replace("&#x26;","&")
	text = (str(text)).replace("&#xFB;","û")
	text = (str(text)).replace("&#xF8;","ø")   
	text = (str(text)).replace("&#x21;","!")                          
	text = (str(text)).replace("&#x3f;","?")
        text = (str(text)).replace("&#304;",  "I")       
        text = (str(text)).replace("&#304;",  "I")
        text = (str(text)).replace("&#39;", "'")
        text = (str(text)).replace('&#39;',"ş")
	text = (str(text)).replace('&#8230;','...')
	text = (str(text)).replace('\u2026','...')  
	text = (str(text)).replace('c59f','ş')
	text = (str(text)).replace('c4b1','ı')
        text = (str(text)).replace('c3b6','ö')
        text = (str(text)).replace('c3bc','ü')                    
        text = (str(text)).replace('c387','Ç')
        text = (str(text)).replace('c3a7','ç')
        text = (str(text)).replace('c396','Ö')
        text = (str(text)).replace('c4b0','İ')
        text = (str(text)).replace('c39c','ü')
        text = (str(text)).replace('c49f','ğ')
        text = (str(text)).replace('&#8234;','')
	text = (str(text)).replace("&#39;", "'")
        text = (str(text)).replace('&#39;',"ş")
	text = (str(text)).replace('&#8230;','...')
	text = (str(text)).replace('\u2026','...')
	text = (str(text)).replace('&hellip;','...')
	text = (str(text)).replace('&#8234;','')
        text = (str(text)).replace("&#231;", "ç")
        text = (str(text)).replace('&#351;',"ş")
	text = (str(text)).replace('&#350;','ş')
	text = (str(text)).replace('&#246;','ö')
	text = (str(text)).replace('&#214;','Ö')
	text = (str(text)).replace('&#199;','Ç')
        return text
def showBoxxx():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    track = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    
    
    
        
    sHosterUrl = track

    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sHosterUrl)
        

    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()  

#UA = 'Mozilla/6.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/8.0 Mobile/10A5376e Safari/8536.25'
    
def GetIp():
    if (False):
        oRequest = cRequestHandler('http://hqq.tv/player/ip.php?type=json')
        oRequest.addHeaderEntry
        sHtmlContent = oRequest.request()
        ip = re.search('"ip":"([^"]+)"', sHtmlContent, re.DOTALL).group(1)
    else:
        import random
        for x in xrange(1,100):
            ip = "192.168."
            ip += ".".join(map(str, (random.randint(0, 255) for _ in range(2))))
        ip = base64.b64encode(ip)

    return ip

def _decode2(file_url):
    def K12K(a, typ='b'):
        codec_a = ["G", "L", "M", "N", "Z", "o", "I", "t", "V", "y", "x", "p", "R", "m", "z", "u",
                   "D", "7", "W", "v", "Q", "n", "e", "0", "b", "="]
        codec_b = ["2", "6", "i", "k", "8", "X", "J", "B", "a", "s", "d", "H", "w", "f", "T", "3",
                   "l", "c", "5", "Y", "g", "1", "4", "9", "U", "A"]
        if 'd' == typ:
            tmp = codec_a
            codec_a = codec_b
            codec_b = tmp
        idx = 0
        while idx < len(codec_a):
            a = a.replace(codec_a[idx], "___")
            a = a.replace(codec_b[idx], codec_a[idx])
            a = a.replace("___", codec_b[idx])
            idx += 1
        return a

    def _xc13(_arg1):
        _lg27 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
        _local2 = ""
        _local3 = [0, 0, 0, 0]
        _local4 = [0, 0, 0]
        _local5 = 0
        while _local5 < len(_arg1):
            _local6 = 0
            while _local6 < 4 and (_local5 + _local6) < len(_arg1):
                _local3[_local6] = _lg27.find(_arg1[_local5 + _local6])
                _local6 += 1
            _local4[0] = ((_local3[0] << 2) + ((_local3[1] & 48) >> 4))
            _local4[1] = (((_local3[1] & 15) << 4) + ((_local3[2] & 60) >> 2))
            _local4[2] = (((_local3[2] & 3) << 6) + _local3[3])

            _local7 = 0
            while _local7 < len(_local4):
                if _local3[_local7 + 1] == 64:
                    break
                _local2 += chr(_local4[_local7])
                _local7 += 1
            _local5 += 4
        return _local2

    return _xc13(K12K(file_url, 'e'))

def hqqtv(url):
    
   
    
        

        headers = {'User-Agent': UA ,
                   #'Host' : 'hqq.tv',
                   'Referer': 'http://hqq.tv/',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                   #'Accept-Encoding':'gzip, deflate, br',
                   #'Content-Type': 'text/html; charset=utf-8'
                   }
        
        player_url =requests.get(url).content 
        
       
        Host = 'https://hqq.watch/'

        data = ''
        code_crypt = re.search('(;eval\(function\(w,i,s,e\){.+?\)\);)\s*<', player_url, re.DOTALL)
        if code_crypt:
            data = unwise.unwise_process(code_crypt.group(1))
        else:
            VSlog('prb1')       
            
        if data:
            http_referer = ''
            _pass = ''
            
            iss = GetIp()
            vid = re.search('var vid *= *"([^"]+)";', data, re.DOTALL).group(1)
            at = re.search('var at *= *"([^"]+)";', data, re.DOTALL).group(1)
            r = re.search('var http_referer *= *"([^"]+)";', data, re.DOTALL)
            if r:
                http_referer = r.group(1)
            
            url2 = Host + "sec/player/embed_player.php?iss="+iss+"&vid="+vid+"&at="+at+"&autoplayed=yes&referer=on&http_referer="+http_referer+"&pass="+_pass+"&embed_from=&need_captcha=0"
            #VSlog( url2 )
            
            req = urllib2.Request(url2,None,headers)
            
            try:
                response = urllib2.urlopen(req)
                data = response.read()
                response.close()
            except urllib2.URLError, e:
                VSlog(e.read())
                VSlog(e.reason)
                data = e.read()

            data = urllib.unquote(data)

            data = DecodeAllThePage(data)

            at = re.search(r'var\s*at\s*=\s*"([^"]*?)"', data)
            
            l = re.search(r'link_1: ([a-zA-Z]+), server_1: ([a-zA-Z]+)', data)
            
            vid_server = re.search(r'var ' + l.group(2) + ' = "([^"]+)"', data).group(1)
            vid_link = re.search(r'var ' + l.group(1) + ' = "([^"]+)"', data).group(1)
            
            #new video id, not really usefull
            m = re.search(r' vid: "([a-zA-Z0-9]+)"}', data)
            if m:
                id = m.group(1)
            
            if vid_server and vid_link and at:

                #get_data = {'server': vid_server.group(1), 'link': vid_link.group(1), 'at': at.group(1), 'adb': '0/','b':'1','vid':id} #,'iss':'MzEuMz'
                get_data = {'server_1': vid_server, 'link_1': vid_link, 'at': at.group(1), 'adb': '0/','b':'1','vid':id}

                headers['x-requested-with'] = 'XMLHttpRequest'

                req = urllib2.Request(Host + "/player/get_md5.php?" + urllib.urlencode(get_data),None,headers)
                try:
                    response = urllib2.urlopen(req)
                except urllib2.URLError, e:
                    VSlog(str(e.read()))
                    VSlog(str(e.reason))
                    
                data = response.read()
                VSlog(data)
                response.close()
                file_url = re.search(r'"file"\s*:\s*"([^"]*?)"', data)
                #Hack, je sais pas si ca va durer longtemps, mais indispensable sur certains fichiers
                list_url = _decode2(file_url.group(1).replace('\\', ''))
                list_url = list_url.replace("?socket", ".mp4.m3u8")  
            else:
                VSlog('prb2')
                
        
        
        
        
       
        Header = 'User-Agent=' + UA
        list_url = list_url + '|' + Header
        

        name = 'videoraj'
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,list_url,'')        
            
        return False, False

                
                   
       
        

#*******************************************************************************

def DecodeAllThePage(html):
    
    #html = urllib.unquote(html)
    
    Maxloop = 10
    
    #unescape
    while (Maxloop > 0):
        Maxloop = Maxloop - 1

        r = re.search(r'unescape\("([^"]+)"\)', html, re.DOTALL | re.UNICODE)
        if not r:
            break
        
        tmp = cUtil().unescape(r.group(1))
        html = html[:r.start()] + tmp + html[r.end():]
        
    #unwise
    while (Maxloop > 0):
        Maxloop = Maxloop - 1

        r = re.search(r'(;eval\(function\(w,i,s,e\){.+?\)\);)\s*<', html, re.DOTALL | re.UNICODE)
        if not r:
            break
        
        tmp = data = unwise.unwise_process(r.group(1))
        html = html[:r.start()] + tmp + html[r.end():]

    return html
import re



def unpackByString( sJavascript):
        aSplit = sJavascript.split(";',")
        p = str(aSplit[0])

        aSplit = aSplit[1].split(",")
        a = int(aSplit[0])
        c = int(aSplit[1])
        k = aSplit[2].split(".")[0].replace("'", '').split('|')
        e = ''
        d = ''
       
        sUnpacked = str(self.__unpack(p, a, c, k, e, d))
        return sUnpacked.replace('\\', '')

def __unpack( p, a, c, k, e, d):
        while (c > 1):
            c = c -1
            if (k[c]):               
                p = re.sub('\\b' + str(self.__itoa(c, a)) +'\\b', k[c], p)
        return p

def __itoa( num, radix):
        result = ""
        while num > 0:
            result = "0123456789abcdefghijklmnopqrstuvwxyz"[num % radix] + result
            num /= radix
        return result  
class getUrl(object):
    def __init__(self, url, close=True, proxy=None, post=None, headers=None, mobile=False, referer=None, cookie=None, output='', timeout='10'):
        handlers = []
        if not proxy == None:
            handlers += [urllib2.ProxyHandler({'http':'%s' % (proxy)}), urllib2.HTTPHandler]
            opener = urllib2.build_opener(*handlers)
            opener = urllib2.install_opener(opener)
        if output == 'cookie' or not close == True:
            import cookielib
            cookies = cookielib.LWPCookieJar()
            handlers += [urllib2.HTTPHandler(), urllib2.HTTPSHandler(), urllib2.HTTPCookieProcessor(cookies)]
            opener = urllib2.build_opener(*handlers)
            opener = urllib2.install_opener(opener)
        try:
            if sys.version_info < (2, 7, 9): raise Exception()
            import ssl; ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            handlers += [urllib2.HTTPSHandler(context=ssl_context)]
            opener = urllib2.build_opener(*handlers)
            opener = urllib2.install_opener(opener)
        except:
            pass
        try: headers.update(headers)
        except: headers = {}
        if 'User-Agent' in headers:
            pass
        elif not mobile == True:
            headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0'
        else:
            headers['User-Agent'] = 'Apple-iPhone/701.341'
        if 'referer' in headers:
            pass
        elif referer == None:
            headers['referer'] = url
        else:
            headers['referer'] = referer
        if not 'Accept-Language' in headers:
            headers['Accept-Language'] = 'en-US'
        if 'cookie' in headers:
            pass
        elif not cookie == None:
            headers['cookie'] = cookie
        request = urllib2.Request(url, data=post, headers=headers)
        response = urllib2.urlopen(request, timeout=int(timeout))
        if output == 'cookie':
            result = []
            for c in cookies: result.append('%s=%s' % (c.name, c.value))
            result = "; ".join(result)
        elif output == 'geturl':
            result = response.geturl()
        else:
            result = response.read()
        if close == True:
            response.close()
        self.result = result
       