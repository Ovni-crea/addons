import xbmcaddon

MainBase = 'aHR0cHM6Ly9nb28uZ2wvOEtRSWQ4'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.Fido')