import re
import urlresolver
from md_request import open_url
import xbmc
import urllib
from ..scraper import Scraper
from ..common import clean_title,clean_search,non_func_hosts

User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'

class mvlinks(Scraper):
    domains = ['http://dl.newmyvideolink.xyz']
    name = "MyVideoLinks"
    sources = []

    def __init__(self):
        self.base_link = 'http://dl.newmyvideolink.xyz'
        self.sources = []

    def scrape_episode(self, title, show_year, year, season, episode, imdb, tvdb, debrid = False):
        try:
            search_id = clean_search(title.lower())
            season_pull = "0%s"%season if len(season)<2 else season
            episode_pull = "0%s"%episode if len(episode)<2 else episode
            
            movie_url = '%s/?s=%s+S%sE%s' %(self.base_link,search_id.replace(' ','+'),season_pull,episode_pull)
            #print 'SEARCH page> '+movie_url
            headers = {'User_Agent':User_Agent}
            link = open_url(movie_url,headers=headers,timeout=5).content
            
            links = link.split('post-title')
            for p in links:

                m_url = re.compile('href="([^"]+)"').findall(p)[0]
                m_title = re.compile('title="([^"]+)"').findall(p)[0]
                #print 'gw>> URL>  '+m_url
                #print 'gw>> TITLE> '+m_title
                if 's%se%s' %(season_pull,episode_pull) in m_title.lower():
                    self.get_source(m_url)
                
            return self.sources
        except Exception, argument:
            return self.sources
        
    def scrape_movie(self, title, year, imdb, debrid=False):
        try:
            search_id = clean_search(title.lower())
            movie_url = '%s/?s=%s' %(self.base_link,search_id.replace(' ','+'))
            #print 'SEARCH page> '+movie_url
            headers = {'User_Agent':User_Agent}
            link = open_url(movie_url,headers=headers,timeout=5).content
            
            links = link.split('post-title')
            for p in links:

                m_url = re.compile('href="([^"]+)"').findall(p)[0]
                m_title = re.compile('title="([^"]+)"').findall(p)[0]
                #print 'gw>> URL>  '+m_url
                #print 'gw>> TITLE> '+m_title
                if clean_title(title).lower() in clean_title(m_title).lower():
                    if year in m_title.lower():
                        self.get_source(m_url)
                
            return self.sources
        except Exception, argument:
            return self.sources

    def get_source(self,m_url):
        try:
            #print ':::::::::::>>> '+m_url
            OPEN = open_url(m_url).content
            match = re.compile('<li><a href="(.+?)"').findall(OPEN)
            for link in match:
                if urlresolver.HostedMediaFile(link).valid_url():   
                    label = link.split('//')[1].replace('www.','')
                    label = label.split('/')[0].split('.')[0].title()
                    label = label.replace('Ul','Uploaded')
                    if '720' in link:
                        rez='720p'
                    elif '1080' in link:
                        rez='1080p'
                    else: 
                        rez='DVD'
                    if not non_func_hosts(label.lower()):
                        continue
                    self.sources.append({'source': label,'quality': rez,'scraper': self.name,'url': link,'direct': False})
        except:
            pass
