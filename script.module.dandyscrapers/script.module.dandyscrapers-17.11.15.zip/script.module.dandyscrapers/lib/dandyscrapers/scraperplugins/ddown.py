import re
from md_request import open_url
import xbmc
import urllib
import urlresolver
from ..scraper import Scraper
from ..common import clean_title,clean_search,non_func_hosts
User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'

class ddown(Scraper):
    domains = ['https://directdownload.tv/']
    name = "DirectDownload"
    sources = []

    def __init__(self):
        self.base_link = 'https://directdownload.tv/'
        self.sources = []
           
            

    def scrape_episode(self,title, show_year, year, season, episode, imdb, tvdb, debrid = False):
        try:            
            season_url = "0%s"%season if len(season)<2 else season
            episode_url = "0%s"%episode if len(episode)<2 else episode

            start_url = 'https://directdownload.tv/api?key=4B0BB862F24C8A29&qualities/disk-480p,disk-1080p-x265,tv-480p,tv-720p,web-480p,web-720p,web-1080p,web-1080p-x265,movie-480p-x265,movie-1080p-x265&limit=50&keyword=%s+s%se%s' %(title.lower(),season_url,episode_url)
            start_url=start_url.replace(' ','%20')


            content = open_url(start_url, timeout=5).content
            links=re.compile('"http(.+?)"',re.DOTALL).findall(content)
            for url in links:
                url = 'http' + url.replace('\/', '/')
                if '720p' in url:
                     res = '720p'
                elif '1080p' in url:
                    res = '1080p'  
                else:
                    res='480p'
                if urlresolver.HostedMediaFile(url).valid_url():
                    host = url.split('//')[1].replace('www.','')
                    host = host.split('/')[0].title()
                    if not non_func_hosts(host.lower()):
                        continue
                    self.sources.append({'source': host,'quality': res,'scraper': self.name,'url': url,'direct': False})
            return self.sources
        except Exception, argument:
            return self.sources  


            

        
