import urlresolver
from md_request import open_url
import re
import xbmc
import urllib
from ..scraper import Scraper
from ..common import clean_title,clean_search            


User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'
                                           
class putlockerz(Scraper):
    domains = ['putlockerz.info']
    name = "Putlockerz"
    sources = []

    def __init__(self):
        self.base_link = 'https://putlockerz.site'


    def scrape_movie(self, title, year, imdb, debrid = False):
        try:
            start_url = self.base_link + '/search_movies?s=' + title.lower().replace(' ','+')
            headers={'User-Agent':User_Agent} 
            Results = open_url(start_url,headers=headers,timeout=5).content
            match = re.compile('<div style=.+?href="(.+?)" title="(.+?)"',re.DOTALL).findall(Results)
            for url,name in match:
                if clean_title(title).lower() in clean_title(name).lower():
                    if year in name:
                        self.get_source(url)
            
            return self.sources
        except:
            pass
            return[]

    def get_source(self,url):
        try:
            #print 'CHECK ###################################### '+url
            headers={'User-Agent':User_Agent}
            OPEN = open_url(url,headers=headers,timeout=5).content
            Regex = re.compile('class="entry2".+?href="(.+?)"',re.DOTALL).findall(OPEN)
            for link in Regex:
                if '/watching/' not in link:
                    host = link.split('//')[1].replace('www.','')
                    host = host.split('/')[0].split('.')[0].title()
                    if 'openload' in link:
                        get=open_url(link,headers=headers,timeout=5).content
                        res= re.compile('name="description" content="(.+?)"',re.DOTALL).findall(get)[0]
                        if '1080' in res:
                            qual = '1080p'
                        elif '720'in res:
                            qual = '720p'
                        else: qual = 'DVD'
                    else:
                        qual = 'DVD'
                    self.sources.append({'source': host, 'quality': qual, 'scraper': self.name, 'url': link,'direct': False})           
        except:
            pass

