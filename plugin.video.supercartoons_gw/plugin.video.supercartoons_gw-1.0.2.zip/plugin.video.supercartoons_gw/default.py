import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os
import xbmcaddon
from addon.common.addon import Addon
from md_request import open_url
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.supercartoons_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/icons/'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
BASEURL = 'http://www.supercartoons.net'


def MENU():
    addDir('[B][COLOR white]Random Cartoons[/COLOR][/B]','http://www.supercartoons.net/',5,ART + 'rand.jpg',FANART,'')
    addDir('[B][COLOR white]By Characters[/COLOR][/B]','http://www.supercartoons.net/characters/1',3,ART + 'char.jpg',FANART,'')
    addDir('[B][COLOR white]By Studios[/COLOR][/B]','http://www.supercartoons.net/studios/1',3,ART + 'studio.jpg',FANART,'')
    addDir('[B][COLOR white]All Cartoons[/COLOR][/B]','http://www.supercartoons.net/cartoons/1',5,ART + 'all_cart.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')

def Get_page(url):
    page=url
    OPEN = open_url(url).content
    Regex = re.compile('<article class="cartoon col-md-3">.+?<a href="(.+?)".+?src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('amp;','')
            icon = 'http://www.supercartoons.net' + icon
            url = 'http://www.supercartoons.net' + url
            if not 'Universal' in name:
                if not 'Paramount' in name:
                    if not 'Columbia' in name:
                        if not 'Filmation' in name:
                            if not '20th Century' in name:
                                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,icon,FANART,'')
    np = re.compile('class="active"><a href=.+?<a href="(.+?)">',re.DOTALL).findall(OPEN)
    for url in np:
        url= page[:-1]+url
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,3,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(500)')
    
def Get_content(url):
    page=url
    OPEN = open_url(url).content
    Regex = re.compile('<article class="cartoon col-md-3">.+?<a href="(.+?)".+?src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('&#039;','\'').replace('amp;','')
            icon = 'http://www.supercartoons.net' + icon
            url = 'http://www.supercartoons.net' + url
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    if '/cartoons/'in page:
        np = re.compile('<ul class="pagination">(.+?)</ul>',re.DOTALL).findall(OPEN)
        np2 = re.compile('class="active"><a href=.+?<a href="(.+?)">',re.DOTALL).findall(str(np))
        for count in np2:
            amount = int(count)
            if amount<11:
                url = page[:-1] + count
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
            if amount>10:
                url = page[:-2] + count
                addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    else:
        np = re.compile('<ul class="pagination">(.+?)</ul>',re.DOTALL).findall(OPEN)
        np2 = re.compile('class="active"><a href=.+?<a href="(.+?)">',re.DOTALL).findall(str(np))
        for url in np2:
            addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]','http://www.supercartoons.net%s'%url,5,ART + 'nextpage.jpg',FANART,'')        
    xbmc.executebuiltin('Container.SetViewMode(50)')

def RESOLVE(name,url):
    OPEN = open_url('http://www.supercartoons.net/ad-preroll.html').content
    referer = url
    headers = {'Host': 'www.supercartoons.net', 'User-Agent': User_Agent, 'Referer': referer}
    head = name
    head = head.replace('[B][COLOR white]','').replace('[/COLOR][/B]','').replace(' ','%20')
    OPEN = open_url(url).content
    vid = re.compile("file: '(.+?)'",re.DOTALL).findall(OPEN)[0] 
    stream_url = vid + '&eb=0&id=&pu=' + url + '&pt=' +head+'|SuperCartoons'
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param


def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 3 : Get_page(url)
elif mode == 5 : Get_content(url) 
elif mode ==100: RESOLVE(name,url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

















